-- MithrilGather : releve de points de recolte (minerais, herbes, gaz, poissons, tresors).
--  * Chaque recolte reussie est enregistree (zone + position).
--  * Les points s'affichent sur la carte du monde et sur la minimap.
--  * /mgather : fenetre de reglages, export et import (copier-coller entre vendeurs).
-- Les points se remplissent au fil de tes recoltes : au debut, il n'y a rien a afficher.

local TAG = "|cffd4a017MithrilGather|r "
local MERGE_DIST = 0.004          -- fusion de deux points identiques (unites de carte)
local MINI_PERIOD = 0.25          -- secondes entre deux mises a jour de la minimap

-- Taille des continents en yards (largeur, hauteur) : valeurs de memoire, voir /mgather debug
local CONTINENTS = {
  [1] = { 36798.56, 24532.39 },   -- Kalimdor
  [2] = { 37714.67, 25143.78 },   -- Royaumes de l'Est
  [3] = { 17463.5, 11642.3 },     -- Outreterre
  [4] = { 17751.3, 11834.2 },     -- Norfendre
}
-- Diametre de la minimap en yards selon le zoom
local MINI_OUT = { [0] = 466.67, [1] = 400, [2] = 333.33, [3] = 266.67, [4] = 200, [5] = 133.33 }
local MINI_IN  = { [0] = 300, [1] = 240, [2] = 180, [3] = 120, [4] = 80, [5] = 50 }

-- Minage, Cueillette, Extraction de gaz, Peche, Ouverture (coffres, palourdes...)
local SPELLS = { [2575] = "ore", [2366] = "herb", [30427] = "gas", [7620] = "fish",
                 [3365] = "treasure", [22810] = "treasure", [6477] = "treasure", [6478] = "treasure" }
local TYPES = { "ore", "herb", "gas", "fish", "treasure" }
local TYPE_LABEL = { ore = "Minerais", herb = "Herbes", gas = "Gaz", fish = "Poissons", treasure = "Tresors" }
local DOT_TEXTURE = "Interface\\CharacterFrame\\TempPortraitAlphaMask"   -- disque plein, rond garanti
local DOT_COLOR = {
  ore  = { 1.0, 0.15, 0.15 },
  herb = { 0.15, 1.0, 0.15 },
  gas  = { 0.3, 0.9, 1.0 },
  fish = { 0.25, 0.5, 1.0 },
  treasure = { 1.0, 0.85, 0.1 },
}
local MAX_SEGS = 32
local DEFAULT_ICON = {
  ore = "Interface\\Icons\\INV_Ore_Copper_01",
  herb = "Interface\\Icons\\INV_Misc_Herb_07",
  gas = "Interface\\Icons\\INV_Elemental_Mote_Air01",
  fish = "Interface\\Icons\\INV_Misc_Fish_02",
  treasure = "Interface\\Icons\\Racial_Dwarf_FindTreasure",
}

-- Noms des bancs de poissons et des tresors : numero GatherMate -> { anglais, francais }
local NODE_NAMES = {
  fish = {
    [101] = { "Floating Wreckage", "Débris flottants" },
    [102] = { "Patch of Elemental Water", "Remous d'eau élémentaire" },
    [103] = { "Floating Debris", "Débris flottant" },
    [104] = { "Oil Spill", "Nappe de pétrole" },
    [105] = { "Firefin Snapper School", "Banc de lutjans de nagefeu" },
    [106] = { "Greater Sagefish School", "Banc de grandes sagerelles" },
    [107] = { "Oily Blackmouth School", "Banc de bouches-noires huileux" },
    [108] = { "Sagefish School", "Banc de sagerelles" },
    [109] = { "School of Deviate Fish", "Banc de poissons déviants" },
    [110] = { "Stonescale Eel Swarm", "Banc d'anguilles pierre-écaille" },
    [112] = { "Highland Mixed School", "Banc mixte des Hautes-terres" },
    [113] = { "Pure Water", "Eau pure" },
    [114] = { "Bluefish School", "Banc de tassergals" },
    [115] = { "Brackish Mixed School", "Banc mixte en eaux saumâtres" },
    [116] = { "Mudfish School", "Banc d'éperlans" },
    [117] = { "School of Darter", "Banc de dards" },
    [118] = { "Sporefish School", "Banc de poissons-spores" },
    [119] = { "Steam Pump Flotsam", "Détritus de la pompe à vapeur" },
    [120] = { "School of Tastyfish", "Banc de courbines" },
    [121] = { "Borean Man O' War School", "Banc de poissons-méduses boréens" },
    [122] = { "Deep Sea Monsterbelly School", "Banc de baudroies abyssales" },
    [123] = { "Dragonfin Angelfish School", "Banc de demoiselles aileron-de-dragon" },
    [124] = { "Fangtooth Herring School", "Banc de harengs crocs-pointus" },
    [125] = { "Floating Wreckage Pool", "Déchets flottants" },
    [126] = { "Glacial Salmon School", "Banc de saumons glaciaires" },
    [127] = { "Glassfin Minnow School", "Banc de vairons nageverres" },
    [128] = { "Imperial Manta Ray School", "Banc de raies manta impériales" },
    [129] = { "Moonglow Cuttlefish School", "Banc de seiches lueur-de-lune" },
    [130] = { "Musselback Sculpin School", "Banc de rascasses dos-de-moule" },
    [131] = { "Nettlefish School", "Banc de méduses" },
    [132] = { "Strange Pool", "Bassin étrange" },
    [133] = { "Schooner Wreckage", "Débris de goélette" },
    [134] = { "Waterlogged Wreckage", "Débris trempés" },
    [135] = { "Bloodsail Wreckage", "Débris de la Voile sanglante" },
    [136] = { "Lesser Sagefish School", "Petit banc de sagerelles" },
    [137] = { "Lesser Oily Blackmouth School", "Petit banc de bouches-noires huileux" },
    [138] = { "Sparse Oily Blackmouth School", "Banc clairsemé de bouches-noires huileux" },
    [139] = { "Abundant Oily Blackmouth School", "Banc abondant de bouches-noires huileux" },
    [140] = { "Teeming Oily Blackmouth School", "Banc grouillant de bouches-noires huileux" },
    [141] = { "Lesser Firefin Snapper School", "Banc clairsemé de lutjans de nagefeu" },
    [142] = { "Sparse Firefin Snapper School", "Banc épars de lutjans de nagefeu" },
    [143] = { "Abundant Firefin Snapper School", "Banc abondant de lutjans de nagefeu" },
    [144] = { "Teeming Firefin Snapper School", "Banc grouillant de lutjans de nagefeu" },
    [145] = { "Lesser Floating Debris", "Débris flottants inférieurs" },
    [146] = { "Sparse Schooner Wreckage", "Débris clairsemés de goélette" },
    [147] = { "Abundant Bloodsail Wreckage", "Débris abondants de la Voile sanglante" },
    [148] = { "Teeming Floating Wreckage", "Débris flottants grouillants" },
  },
  treasure = {
    [501] = { "Giant Clam", "Palourde géante" },
    [502] = { "Battered Chest", "Coffre endommagé" },
    [503] = { "Tattered Chest", "Coffre en morceaux" },
    [504] = { "Solid Chest", "Coffre solide" },
    [505] = { "Large Iron Bound Chest", "Grand coffre cerclé de fer" },
    [506] = { "Large Solid Chest", "Grand coffre solide" },
    [507] = { "Large Battered Chest", "Grand coffre endommagé" },
    [508] = { "Buccaneer's Strongbox", "Coffre des boucaniers" },
    [509] = { "Large Mithril Bound Chest", "Grand coffre cerclé de mithril" },
    [510] = { "Large Darkwood Chest", "Grand coffre de sombrebois" },
    [511] = { "Un'Goro Dirt Pile", "Tas de poussière d'Un'Goro" },
    [512] = { "Bloodpetal Sprout", "Pousse de Pétale-de-sang" },
    [513] = { "Blood of Heroes", "Sang des héros" },
    [514] = { "Practice Lockbox", "Coffret d'apprentissage" },
    [515] = { "Battered Footlocker", "Cantine endommagée" },
    [516] = { "Waterlogged Footlocker", "Cantine détrempée" },
    [517] = { "Dented Footlocker", "Cantine abîmée" },
    [518] = { "Mossy Footlocker", "Cantine moisie" },
    [519] = { "Scarlet Footlocker", "Cantine écarlate" },
    [520] = { "Burial Chest", "Coffre funéraire" },
    [521] = { "Fel Iron Chest", "Coffre en gangrefer" },
    [522] = { "Heavy Fel Iron Chest", "Coffre lourd en gangrefer" },
    [523] = { "Adamantite Bound Chest", "Coffre cerclé d'adamantite" },
    [524] = { "Felsteel Chest", "Coffre en gangracier" },
    [525] = { "Glowcap", "Chapeluisant" },
    [526] = { "Wicker Chest", "Coffre en osier" },
    [527] = { "Primitive Chest", "Coffre primitif" },
    [528] = { "Solid Fel Iron Chest", "Coffre solide en gangrefer" },
    [529] = { "Bound Fel Iron Chest", "Coffre cerclé de gangrefer" },
    [531] = { "Netherwing Egg", "Oeuf de l'Aile-du-Néant" },
    [532] = { "Everfrost Chip", "Morceau de permagivre" },
    [533] = { "Brightly Colored Egg", "Oeuf vivement coloré" },
  },
}

-- reconnaissance par le nom (insensible a la casse), pour ne retenir QUE de vrais points de peche / de tresor
local KNOWN_NAME = { fish = {}, treasure = {} }
local function Fold(s) return string.lower(tostring(s or "")) end
for kind, tbl in pairs(NODE_NAMES) do
  for _, pair in pairs(tbl) do
    KNOWN_NAME[kind][Fold(pair[1])] = true
    KNOWN_NAME[kind][Fold(pair[2])] = true
  end
end
-- nom affiche d'un numero GatherMate dans la langue du client (anglais par defaut)
local function EmbeddedName(kind, id)
  local pair = NODE_NAMES[kind] and NODE_NAMES[kind][id]
  if not pair then return nil end
  return (GetLocale and GetLocale() == "frFR") and pair[2] or pair[1]
end

MithrilGatherDB = MithrilGatherDB or {}
local G = {}
MithrilGather = G

local function Print(msg) DEFAULT_CHAT_FRAME:AddMessage(TAG .. tostring(msg)) end

-- Les variables sauvegardees arrivent APRES ce fichier : on complete la base a chaque entree.
local function EnsureDB()
  MithrilGatherDB = MithrilGatherDB or {}
  local d = MithrilGatherDB
  d.nodes = d.nodes or {}          -- [cleZone] = { {x,y,cx,cy,c,n,t}, ... }
  d.cal = d.cal or {}             -- [cleZone] = calibration zone -> continent (pour les points importes)
  d.icons = d.icons or {}          -- [nomDuPoint] = texture
  d.show = d.show or { ore = true, herb = true, gas = true }
  if d.show.fish == nil then d.show.fish = true end
  if d.show.treasure == nil then d.show.treasure = true end
  if d.world == nil then d.world = true end
  if d.mini == nil then d.mini = true end
  if type(d.miniSize) ~= "number" then d.miniSize = 14 end
  if type(d.miniAlpha) ~= "number" then d.miniAlpha = 90 end
  if type(d.miniThick) ~= "number" then d.miniThick = 3 end   -- pourcentage
  if type(d.worldSize) ~= "number" then d.worldSize = 10 end   -- taille des icones sur la carte du monde
  -- migration unique : anciennes versions stockaient mini=false / miniIcons=true
  if (d.ver or 0) < 4 then d.mini = true; d.miniIcons = false; d.miniSize = 14; d.miniAlpha = 90 end
  -- v5 : les anciennes icones venaient parfois d'une gemme du butin -> on les reapprend
  if (d.ver or 0) < 5 then d.icons = {} end
  d.ver = 5
  if d.miniIcons == nil then d.miniIcons = false end   -- false = ronds transparents (ne cachent pas le point reel)
  return d
end
EnsureDB()

local spellType = {}              -- nom localise du sort -> type
local function BuildSpellNames()
  for id, t in pairs(SPELLS) do
    local name = GetSpellInfo and GetSpellInfo(id)
    if name then spellType[name] = t end
  end
end

-- ------------------------------------------------------------------ donnees
local function NodeCount()
  local n = 0
  for _, list in pairs(EnsureDB().nodes) do n = n + #list end
  return n
end

-- Ajoute un point (fusionne avec un point proche du meme nom). Renvoie true si c'est un nouveau point.
function G.Add(key, c, name, t, x, y, cx, cy)
  local d = EnsureDB()
  local list = d.nodes[key]
  if not list then list = {}; d.nodes[key] = list end
  for _, nd in ipairs(list) do
    if nd.n == name and (nd.x - x) ^ 2 + (nd.y - y) ^ 2 < MERGE_DIST ^ 2 then
      if cx and not nd.cx then nd.cx, nd.cy = cx, cy end
      return false
    end
  end
  table.insert(list, { x = x, y = y, cx = cx, cy = cy, c = c, n = name, t = t })
  return true
end

local function Round(v) return math.floor(v * 100000 + 0.5) / 100000 end

-- Export texte : une ligne par point, plus les icones connues
function G.Export()
  local d = EnsureDB()
  local out = { "MITHRILGATHER1" }
  for name, tex in pairs(d.icons) do
    table.insert(out, "I|" .. name .. "|" .. tex)
  end
  for key, list in pairs(d.nodes) do
    for _, nd in ipairs(list) do
      table.insert(out, table.concat({ "N", key, nd.c or 0, nd.t, nd.n, Round(nd.x), Round(nd.y),
        nd.cx and Round(nd.cx) or "", nd.cy and Round(nd.cy) or "" }, "|"))
    end
  end
  return table.concat(out, "\n")
end

-- Import : fusionne avec les points existants. Renvoie (nouveaux, ignores)
function G.Import(text)
  local d = EnsureDB()
  local added, skipped = 0, 0
  local first = true
  for line in string.gmatch(text or "", "[^\r\n]+") do
    if first then
      first = false
      if not string.find(line, "^MITHRILGATHER1") then return 0, 0, "Format inconnu (la premiere ligne doit etre MITHRILGATHER1)." end
    else
      local f = {}
      for part in string.gmatch(line .. "|", "([^|]*)|") do table.insert(f, part) end
      if f[1] == "I" and f[2] and f[3] and f[2] ~= "" then
        if not d.icons[f[2]] then d.icons[f[2]] = f[3] end
      elseif f[1] == "N" and #f >= 7 then
        local x, y = tonumber(f[6]), tonumber(f[7])
        local t = f[4]
        if x and y and DEFAULT_ICON[t] and f[2] ~= "" and f[5] ~= "" then
          if G.Add(f[2], tonumber(f[3]), f[5], t, x, y, tonumber(f[8]), tonumber(f[9])) then
            added = added + 1
          else
            skipped = skipped + 1
          end
        end
      end
    end
  end
  return added, skipped
end

-- ------------------------------------------------------------------ calibration zone -> continent
-- La minimap a besoin de coordonnees continent. Les points importes n'ont que des coordonnees de
-- zone : on apprend la transformation de chaque zone quand tu t'y deplaces (une ancre + l'echantillon
-- le plus eloigne sur chaque axe).
function G.Calibrate(st)
  if not st or not st.cx then return end
  local cal = EnsureDB().cal[st.key]
  if not cal then
    EnsureDB().cal[st.key] = { c = st.c, ax = st.x, ay = st.y, acx = st.cx, acy = st.cy }
    return
  end
  local dx = math.abs(st.x - cal.ax)
  if dx > 0.02 and dx > (cal.dxs or 0) then
    cal.sx = (st.cx - cal.acx) / (st.x - cal.ax); cal.dxs = dx
  end
  local dy = math.abs(st.y - cal.ay)
  if dy > 0.02 and dy > (cal.dys or 0) then
    cal.sy = (st.cy - cal.acy) / (st.y - cal.ay); cal.dys = dy
  end
end

-- Convertit une position de zone en position continent (nil tant que la zone n'est pas calibree)
function G.ToContinent(key, x, y)
  local cal = EnsureDB().cal[key]
  if cal and cal.sx and cal.sy then
    return cal.acx + (x - cal.ax) * cal.sx, cal.acy + (y - cal.ay) * cal.sy
  end
  return nil
end

-- ------------------------------------------------------------------ import GatherMate / GatherMate2
-- Lit les donnees des add-ons GatherMate2 (variables GatherMate2MineDB / HerbDB / GasDB) et GatherMate 1
-- (variables dont le nom commence par GatherMate et contient Mine/Mining, Herb ou Gas).
-- Structure attendue : [zone][coord] = idDuPoint, avec la zone en identifiant de carte OU en nom.
-- Codage de coord : GatherMate2 = x*10000*1000000 + y*10000*100 + etage ; GatherMate 1 = x*10000*10000 + y*10000
-- (detecte automatiquement selon la taille des valeurs).
local KIND_BY_TYPE = { ore = "Mining", herb = "Herb Gathering", gas = "Extract Gas", fish = "Fishing", treasure = "Treasure" }

local function SourceType(name)
  local low = string.lower(name)
  if string.find(low, "mine") or string.find(low, "mining") then return "ore" end
  if string.find(low, "herb") then return "herb" end
  if string.find(low, "gas") then return "gas" end
  if string.find(low, "fish") then return "fish" end
  if string.find(low, "treasure") then return "treasure" end
  return nil
end

-- Liste des tables de donnees GatherMate presentes : { {global=, t=, gm2=bool}, ... }
local function FindSources()
  local out = {}
  for name, v in pairs(_G) do
    if type(name) == "string" and type(v) == "table" and string.find(name, "^GatherMate") and string.find(name, "DB$") then
      local t = SourceType(name)
      if t then
        table.insert(out, { global = name, t = t, gm2 = (string.find(name, "^GatherMate2") ~= nil) })
      end
    end
  end
  table.sort(out, function(a, b) return a.global < b.global end)
  return out
end

-- Acces aux noms localises des points via l'add-on lui-meme (GatherMate2 ou GatherMate 1), si possible
local function NameResolver()
  local candidates = {}
  if LibStub then
    local ok, AceAddon = pcall(LibStub, "AceAddon-3.0", true)
    if ok and AceAddon and AceAddon.GetAddon then
      local ok2, addon = pcall(AceAddon.GetAddon, AceAddon, "GatherMate2", true)
      if ok2 and addon then table.insert(candidates, addon) end
    end
  end
  if type(_G.GatherMate) == "table" then table.insert(candidates, _G.GatherMate) end
  return function(kind, id)
    for _, gm in ipairs(candidates) do
      local name
      if type(gm.reverseNodeIDs) == "table" and gm.reverseNodeIDs[kind] then name = gm.reverseNodeIDs[kind][id] end
      if not name and type(gm.GetNameForNode) == "function" then
        local ok, r = pcall(gm.GetNameForNode, gm, kind, id)
        if ok then name = r end
      end
      if type(name) == "string" and name ~= "" then return name end
    end
    return EmbeddedName(kind == "Fishing" and "fish" or kind == "Treasure" and "treasure" or "", id)
  end
end

-- GatherMate 1 numerote les zones avec SA PROPRE table (zoneData), differente des identifiants de carte du jeu :
-- id GatherMate 1 -> { fichier de carte, continent (1 Kalimdor, 2 Royaumes de l'Est, 3 Outreterre, 4 Norfendre) }
local GM1_ZONES = {
  [1] = { "Arathi", 2 }, [2] = { "Ogrimmar", 1 }, [4] = { "Undercity", 2 }, [5] = { "Barrens", 1 },
  [6] = { "Darnassis", 1 }, [7] = { "AzuremystIsle", 1 }, [8] = { "UngoroCrater", 1 }, [9] = { "BurningSteppes", 2 },
  [10] = { "Wetlands", 2 }, [11] = { "Winterspring", 1 }, [12] = { "Dustwallow", 1 }, [13] = { "Darkshore", 1 },
  [14] = { "LochModan", 2 }, [15] = { "BladesEdgeMountains", 3 }, [16] = { "Durotar", 1 }, [17] = { "Silithus", 1 },
  [18] = { "ShattrathCity", 3 }, [19] = { "Ashenvale", 1 }, [21] = { "Nagrand", 3 }, [22] = { "TerokkarForest", 3 },
  [23] = { "EversongWoods", 2 }, [24] = { "SilvermoonCity", 2 }, [25] = { "Tanaris", 1 }, [26] = { "Stormwind", 2 },
  [27] = { "SwampOfSorrows", 2 }, [28] = { "EasternPlaguelands", 2 }, [29] = { "BlastedLands", 2 }, [30] = { "Elwynn", 2 },
  [31] = { "DeadwindPass", 2 }, [32] = { "DunMorogh", 2 }, [33] = { "TheExodar", 1 }, [34] = { "Felwood", 1 },
  [35] = { "Silverpine", 2 }, [36] = { "ThunderBluff", 1 }, [37] = { "Hinterlands", 2 }, [38] = { "StonetalonMountains", 1 },
  [39] = { "Mulgore", 1 }, [40] = { "Hellfire", 3 }, [41] = { "Ironforge", 2 }, [42] = { "ThousandNeedles", 1 },
  [43] = { "Stranglethorn", 2 }, [44] = { "Badlands", 2 }, [45] = { "Teldrassil", 1 }, [46] = { "Moonglade", 1 },
  [47] = { "ShadowmoonValley", 3 }, [48] = { "Tirisfal", 2 }, [49] = { "Aszhara", 1 }, [50] = { "Redridge", 2 },
  [51] = { "BloodmystIsle", 1 }, [52] = { "WesternPlaguelands", 2 }, [53] = { "Alterac", 2 }, [54] = { "Westfall", 2 },
  [55] = { "Duskwood", 2 }, [56] = { "Netherstorm", 3 }, [57] = { "Ghostlands", 2 }, [58] = { "Zangarmarsh", 3 },
  [59] = { "Desolace", 1 }, [61] = { "SearingGorge", 2 }, [63] = { "Feralas", 1 }, [64] = { "Hilsbrad", 2 },
  [65] = { "Sunwell", 2 }, [67] = { "BoreanTundra", 4 }, [68] = { "Dragonblight", 4 }, [69] = { "GrizzlyHills", 4 },
  [70] = { "HowlingFjord", 4 }, [71] = { "IcecrownGlacier", 4 }, [72] = { "SholazarBasin", 4 }, [73] = { "TheStormPeaks", 4 },
  [74] = { "ZulDrak", 4 }, [77] = { "CrystalsongForest", 4 }, [78] = { "LakeWintergrasp", 4 }, [80] = { "Dalaran", 4 },
  [143] = { "HrothgarsLanding", 4 },
}

local function Gm1Info(zone, byName)
  local z = GM1_ZONES[zone]
  if not z then return nil end
  return byName[z[1]] or { key = z[1], c = z[2] }
end

-- Table idDeZone / nomDeZone -> {cle, continent}, construite avec les cartes du jeu (carte du monde fermee)
local function BuildZoneIndex()
  local byId, byName = {}, {}
  if not (GetMapContinents and GetMapZones and SetMapZoom) then return byId, byName end
  local conts = { GetMapContinents() }
  for c = 1, #conts do
    local zones = { GetMapZones(c) }
    for z = 1, #zones do
      SetMapZoom(c, z)
      local key = GetMapInfo()
      if key and key ~= "" then
        local aid = GetCurrentMapAreaID and GetCurrentMapAreaID()
        if aid then byId[aid] = { key = key, c = c } end
        byName[zones[z]] = { key = key, c = c }
        byName[key] = { key = key, c = c }
      end
    end
  end
  SetMapToCurrentZone()
  return byId, byName
end

local function DecodeCoord(coord, gm2style)
  if gm2style then
    return math.floor(coord / 1000000) / 10000, math.floor(coord % 1000000 / 100) / 10000
  end
  return math.floor(coord / 10000) / 10000, (coord % 10000) / 10000
end

local function MaxCoord(store)
  local m = 0
  for _, data in pairs(store) do
    if type(data) == "table" then
      for coord in pairs(data) do if type(coord) == "number" and coord > m then m = coord end end
    end
  end
  return m
end

function G.ImportGM2()
  if WorldMapFrame and WorldMapFrame:IsVisible() then return nil, "Ferme la carte du monde avant d'importer." end
  local sources = FindSources()
  if #sources == 0 then
    return nil, "Donnees GatherMate introuvables : installe et active GatherMate ou GatherMate2, puis /reload et reessaie."
  end
  local d = EnsureDB()
  local resolve = NameResolver()
  local byId, byName = BuildZoneIndex()
  -- doublons : exact au 1/10000e pres entre points GatherMate ; proximite (0.0015) avec tes points deja enregistres.
  -- (avant, une grille trop large fusionnait des filons voisins distincts -> points "manquants")
  -- Correction des imports faits avec les anciennes versions : les zones GatherMate 1 etaient lues comme des
  -- identifiants de carte du jeu (ex. Hellfire rangee dans Westfall). On retire ces points mal ranges
  -- (meme nom, memes coordonnees au 1/10000e) avant de les reimporter dans la bonne zone.
  local fixed = 0
  do
    local purge = {}
    for _, src in ipairs(sources) do
      local db = _G[src.global]
      local store = rawget(db, "__gm2_base_storage") or db
      if not (src.gm2 or MaxCoord(store) >= 1e9) then
        for zone, data in pairs(store) do
          local good = type(zone) == "number" and type(data) == "table" and Gm1Info(zone, byName)
          local old = good and byId[zone]
          if good and old and old.key ~= good.key then
            local set = purge[old.key]; if not set then set = {}; purge[old.key] = set end
            for coord, id in pairs(data) do
              if type(coord) == "number" and type(id) == "number" then
                local x, y = DecodeCoord(coord, false)
                local name = resolve(KIND_BY_TYPE[src.t], id) or (TYPE_LABEL[src.t] .. " #" .. id)
                set[name .. "|" .. math.floor(x * 10000 + 0.5) .. "|" .. math.floor(y * 10000 + 0.5)] = true
              end
            end
          end
        end
      end
    end
    for key, set in pairs(purge) do
      local list = d.nodes[key]
      if list then
        local keep = {}
        for _, nd in ipairs(list) do
          if set[nd.n .. "|" .. math.floor(nd.x * 10000 + 0.5) .. "|" .. math.floor(nd.y * 10000 + 0.5)] then
            fixed = fixed + 1
          else
            keep[#keep + 1] = nd
          end
        end
        if #keep == 0 then d.nodes[key] = nil else d.nodes[key] = keep end
      end
    end
  end
  local seen = {}
  local CELL = 0.002
  local near = {}
  local function gcell(key, name, cx, cy) return key .. "|" .. name .. "|" .. cx .. "|" .. cy end
  local function addNear(key, name, x, y)
    local k = gcell(key, name, math.floor(x / CELL), math.floor(y / CELL))
    local t = near[k]; if not t then t = {}; near[k] = t end
    t[#t + 1] = { x, y }
  end
  local function isNear(key, name, x, y)
    local cx, cy = math.floor(x / CELL), math.floor(y / CELL)
    for dx = -1, 1 do
      for dy = -1, 1 do
        local t = near[gcell(key, name, cx + dx, cy + dy)]
        if t then
          for _, q in ipairs(t) do
            if (q[1] - x) ^ 2 + (q[2] - y) ^ 2 < 0.0015 ^ 2 then return true end
          end
        end
      end
    end
    return false
  end
  for key, list in pairs(d.nodes) do
    for _, nd in ipairs(list) do addNear(key, nd.n, nd.x, nd.y) end
  end
  local added, dup, bad = 0, 0, 0
  local unknownZone, unknownPts, resolved = {}, {}, {}
  for _, src in ipairs(sources) do
    local db = _G[src.global]
    local store = rawget(db, "__gm2_base_storage") or db
    local gm2style = src.gm2 or MaxCoord(store) >= 1e9
    for zone, data in pairs(store) do
      if type(data) == "table" then
        local info
        if not gm2style and type(zone) == "number" then
          info = Gm1Info(zone, byName)        -- GatherMate 1 : numerotation propre a l'add-on
        else
          info = byId[zone] or byName[zone]   -- GatherMate2 : identifiants de carte du jeu
        end
        if not info and gm2style and type(zone) == "number" and SetMapByID then
          -- zone absente de la liste des cartes : on demande au jeu a quelle carte correspond cet identifiant.
          -- Accepte seulement si le jeu confirme le meme identifiant (sinon on risquerait de mal ranger les points).
          local ok = pcall(SetMapByID, zone)
          if ok then
            local key = GetMapInfo and GetMapInfo()
            local c = GetCurrentMapContinent and GetCurrentMapContinent()
            local aid = GetCurrentMapAreaID and GetCurrentMapAreaID()
            if key and key ~= "" and c and c > 0 and (aid == nil or aid == zone) then
              info = { key = key, c = c }
              byId[zone] = info
              resolved[zone] = key
            end
          end
        end
        if not info then
          unknownZone[tostring(zone)] = true
          local c = 0
          for _ in pairs(data) do c = c + 1 end
          unknownPts[tostring(zone)] = (unknownPts[tostring(zone)] or 0) + c
        else
          for coord, id in pairs(data) do
            if type(coord) == "number" and type(id) == "number" then
              local x, y = DecodeCoord(coord, gm2style)
              if x <= 0 or y <= 0 or x >= 1 or y >= 1 then
                bad = bad + 1
              else
                local name = resolve(KIND_BY_TYPE[src.t], id) or (TYPE_LABEL[src.t] .. " #" .. id)
                local k = info.key .. "|" .. name .. "|" .. math.floor(x * 10000 + 0.5) .. "|" .. math.floor(y * 10000 + 0.5)
                if seen[k] or isNear(info.key, name, x, y) then
                  dup = dup + 1
                else
                  seen[k] = true
                  local list = d.nodes[info.key]
                  if not list then list = {}; d.nodes[info.key] = list end
                  table.insert(list, { x = x, y = y, c = info.c, n = name, t = src.t })
                  added = added + 1
                end
              end
            end
          end
        end
      end
    end
  end
  if SetMapToCurrentZone then SetMapToCurrentZone() end
  local nUnknown = 0
  for _ in pairs(unknownZone) do nUnknown = nUnknown + 1 end
  return added, dup, nUnknown, bad, unknownPts, resolved, fixed
end

-- Diagnostic : decrit ce qui est present (aide a adapter l'import a une version precise)
function G.ScanGM()
  local lines = {}
  local sources = FindSources()
  if #sources == 0 then return { "Aucune table de donnees GatherMate trouvee (add-on non charge ?)." } end
  for _, src in ipairs(sources) do
    local db = _G[src.global]
    local store = rawget(db, "__gm2_base_storage") or db
    local zones, nodes = 0, 0
    local zk, ck, cv
    for zone, data in pairs(store) do
      if type(data) == "table" then
        zones = zones + 1
        if not zk then zk = zone end
        for coord, id in pairs(data) do
          nodes = nodes + 1
          if not ck then ck, cv = coord, id end
        end
      end
    end
    table.insert(lines, string.format("%s : %d zones, %d points, exemple zone=%s (%s) coord=%s id=%s",
      src.global, zones, nodes, tostring(zk), type(zk), tostring(ck), tostring(cv)))
  end
  return lines
end

-- ------------------------------------------------------------------ position du joueur
-- Renvoie cleZone, continent, x, y (zone), cx, cy (continent) ou nil
local lastState
local function PlayerState()
  if WorldMapFrame and WorldMapFrame:IsVisible() then return lastState end
  SetMapToCurrentZone()
  local c, z = GetCurrentMapContinent(), GetCurrentMapZone()
  if not c or c < 1 or not z or z < 1 then lastState = nil; return nil end
  local x, y = GetPlayerMapPosition("player")
  if not x or (x == 0 and y == 0) then lastState = nil; return nil end
  local key = GetMapInfo()
  if not key or key == "" then lastState = nil; return nil end
  local cx, cy
  SetMapZoom(c)
  cx, cy = GetPlayerMapPosition("player")
  SetMapToCurrentZone()
  if not cx or (cx == 0 and cy == 0) then cx, cy = nil, nil end
  lastState = { key = key, c = c, x = x, y = y, cx = cx, cy = cy }
  return lastState
end

-- Projection minimap : renvoie (dx, dy) en pixels depuis le centre, ou nil si hors de portee
function G.Project(px, py, nx, ny, cont, zoom, indoors, mapSize, facing, rotate)
  local dims = CONTINENTS[cont]
  if not dims then return nil end
  local diameter = (indoors and MINI_IN or MINI_OUT)[zoom]
  if not diameter then return nil end
  local sx = (nx - px) * dims[1]            -- yards vers l'est
  local sy = -(ny - py) * dims[2]           -- yards vers le nord
  if rotate and facing then
    local cf, sf = math.cos(facing), math.sin(facing)
    sx, sy = sx * cf + sy * sf, -sx * sf + sy * cf
  end
  if sx * sx + sy * sy > (diameter / 2) ^ 2 then return nil end
  local k = mapSize / diameter
  return sx * k, sy * k
end

-- ------------------------------------------------------------------ enregistrement
-- mots sans valeur pour comparer un nom de filon ("Filon de cuivre") a celui du minerai ("Minerai de cuivre")
local STOP = { filon = true, riche = true, gisement = true, depot = true, ["dépôt"] = true, amas = true,
               veine = true, minerai = true, school = true, banc = true, bancs = true, de = true, du = true, des = true, la = true, le = true,
               les = true, ["d"] = true, ["l"] = true, vein = true, deposit = true, rich = true, ore = true }
local function Tokens(name)
  local t = {}
  for w in string.gmatch(string.lower(tostring(name or "")), "[^%s'%-%.,]+") do
    if #w > 2 and not STOP[w] then t[w] = true end
  end
  return t
end
-- vrai si les deux noms partagent un mot significatif (cuivre, mithril, saronite, lotus...)
function G.NameMatches(nodeName, itemName)
  if not nodeName or not itemName then return false end
  local a = Tokens(nodeName)
  for w in pairs(Tokens(itemName)) do
    if a[w] then return true end
  end
  return false
end

-- Peche / coffres : le nom du point vient de la cible du sort ou, a defaut, de l'info-bulle de ce que le curseur
-- survole (comme GatherMate). On ne retient que les noms connus : ni PNJ, ni portes, ni quetes.
local function KnownNode(kind, text)
  if type(text) == "string" and text ~= "" and KNOWN_NAME[kind][Fold(text)] then return text end
  return nil
end
local function HoverText()
  if GameTooltip and GameTooltip.IsVisible and GameTooltip:IsVisible() and GameTooltipTextLeft1 then
    return GameTooltipTextLeft1:GetText()
  end
  return nil
end

local pending, lastNode
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("UNIT_SPELLCAST_SENT")
ev:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
ev:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")   -- la peche est un sort canalise
ev:RegisterEvent("UNIT_SPELLCAST_FAILED")
ev:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
ev:RegisterEvent("LOOT_OPENED")
ev:RegisterEvent("WORLD_MAP_UPDATE")

local RefreshWorld

ev:SetScript("OnEvent", function(self, event, a1, a2, a3, a4)
  if event == "PLAYER_LOGIN" then
    EnsureDB(); BuildSpellNames()
    -- autres langues : si GatherMate est installe, ses noms de poissons / coffres sont reconnus aussi
    pcall(function()
      local resolve = NameResolver()
      for kind, gmKind in pairs({ fish = "Fishing", treasure = "Treasure" }) do
        for id in pairs(NODE_NAMES[kind]) do
          local n = resolve(gmKind, id)
          if n then KNOWN_NAME[kind][Fold(n)] = true end
        end
      end
    end)
    Print("charge. /mgather pour les reglages. Les points se remplissent au fil de tes recoltes.")
  elseif event == "UNIT_SPELLCAST_SENT" then
    -- a1 = unit, a2 = sort, a3 = rang, a4 = cible
    if a1 == "player" and spellType[a2] then
      local t = spellType[a2]
      local name
      if t == "fish" or t == "treasure" then
        name = KnownNode(t, a4) or KnownNode(t, HoverText())
      elseif a4 and a4 ~= "" then
        name = a4
      end
      local st = name and PlayerState()
      if st then pending = { name = name, spell = a2, t = t, st = st, at = GetTime() } else pending = nil end
    end
  elseif event == "UNIT_SPELLCAST_SUCCEEDED" or event == "UNIT_SPELLCAST_CHANNEL_START" then
    if a1 == "player" and pending and a2 == pending.spell and (GetTime() - pending.at) < 30 then
      local p = pending; pending = nil
      G.Calibrate(p.st)
      local cx, cy = p.st.cx, p.st.cy
      if p.t == "fish" and cx then
        -- le banc est a ~20 yards devant le joueur, dans la direction du regard
        local f = GetPlayerFacing and GetPlayerFacing()
        local dims = CONTINENTS[p.st.c]
        if f and dims then cx, cy = cx - math.sin(f) * 20 / dims[1], cy - math.cos(f) * 20 / dims[2] end
      end
      local isNew = G.Add(p.st.key, p.st.c, p.name, p.t, p.st.x, p.st.y, cx, cy)
      lastNode = { name = p.name, at = GetTime() }
      if isNew then Print("Nouveau point : " .. p.name) end
      if RefreshWorld then RefreshWorld() end
    end
  elseif event == "UNIT_SPELLCAST_FAILED" or event == "UNIT_SPELLCAST_INTERRUPTED" then
    if a1 == "player" then pending = nil end
  elseif event == "LOOT_OPENED" then
    -- l'icone du point = celle du butin dont le nom correspond au filon / a la plante
    -- (pas le premier objet : un filon donne aussi des gemmes, qui ne doivent pas servir d'icone)
    if lastNode and (GetTime() - lastNode.at) < 15 then
      local d = EnsureDB()
      if GetLootSlotInfo then
        local n = (GetNumLootItems and GetNumLootItems()) or 1
        for slot = 1, n do
          local tex, itemName = GetLootSlotInfo(slot)
          if tex and G.NameMatches(lastNode.name, itemName) then
            d.icons[lastNode.name] = tex
            if RefreshWorld then RefreshWorld() end
            break
          end
        end
      end
      lastNode = nil
    end
  elseif event == "WORLD_MAP_UPDATE" then
    if RefreshWorld then RefreshWorld() end
  end
end)

-- ------------------------------------------------------------------ carte du monde
local worldPins = {}
-- Sur la carte du monde, le jeu affiche ses info-bulles dans WorldMapTooltip (GameTooltip y reste invisible)
local function MapTip() return WorldMapTooltip or GameTooltip end
local function GetPin(i)
  local p = worldPins[i]
  if not p then
    p = CreateFrame("Button", nil, WorldMapButton)
    p:SetWidth(10); p:SetHeight(10)
    p:SetFrameLevel(WorldMapButton:GetFrameLevel() + 20)
    p:EnableMouse(true)
    p.tex = p:CreateTexture(nil, "OVERLAY")
    p.tex:SetAllPoints(p)
    -- l'info-bulle est geree par G.WorldHover (position du curseur), pas par OnEnter/OnLeave
    worldPins[i] = p
  end
  return p
end

RefreshWorld = function()
  if not (WorldMapFrame and WorldMapButton) then return end
  for _, p in ipairs(worldPins) do p:Hide() end
  local d = EnsureDB()
  if not d.world or not WorldMapFrame:IsVisible() then return end
  if (GetCurrentMapZone() or 0) < 1 then return end
  local key = GetMapInfo()
  local list = key and d.nodes[key]
  if not list then return end
  local w, h = WorldMapButton:GetWidth(), WorldMapButton:GetHeight()
  local n = 0
  for _, nd in ipairs(list) do
    if d.show[nd.t] and n < 1500 then
      n = n + 1
      local p = GetPin(n)
      p.nodeName = nd.n
      p.nodeType = nd.t
      p.px, p.py = nd.x * w, nd.y * h
      p:SetWidth(d.worldSize); p:SetHeight(d.worldSize)
      p.tex:SetTexture(d.icons[nd.n] or DEFAULT_ICON[nd.t])
      p:ClearAllPoints()
      p:SetPoint("CENTER", WorldMapButton, "TOPLEFT", nd.x * w, -nd.y * h)
      p:Show()
    end
  end
end

-- Info-bulle au survol, calculee a partir de la position du curseur (ne depend pas du systeme de souris des
-- icones : certaines cartes / add-ons de carte captent la souris au-dessus d'elles).
local hoverShown = false
function G.WorldHover()
  local d = EnsureDB()
  local found
  if d.world and WorldMapFrame and WorldMapFrame:IsVisible() and WorldMapButton and WorldMapButton.GetLeft then
    local left, top = WorldMapButton:GetLeft(), WorldMapButton:GetTop()
    local scale = WorldMapButton:GetEffectiveScale()
    local mx, my = GetCursorPosition()
    if left and top and scale and scale > 0 and mx then
      local rx, ry = mx / scale - left, top - my / scale
      local best = (d.worldSize / 2 + 4) ^ 2
      for _, p in ipairs(worldPins) do
        if p:IsShown() and p.px then
          local dd = (p.px - rx) ^ 2 + (p.py - ry) ^ 2
          if dd <= best then best = dd; found = p end
        end
      end
    end
  end
  if found then
    -- deja affichee pour ce point : on ne la reconstruit pas a chaque passage
    if hoverShown ~= found then
      local tip = MapTip()
      tip:SetOwner(WorldMapButton, "ANCHOR_CURSOR")
      tip:ClearLines()
      tip:AddLine(found.nodeName or "?", 1, 1, 1)
      if found.nodeType and TYPE_LABEL[found.nodeType] then tip:AddLine(TYPE_LABEL[found.nodeType], 0.7, 0.7, 0.7) end
      tip:Show()
      hoverShown = found
    end
    return found.nodeName
  elseif hoverShown then
    hoverShown = false
    MapTip():Hide()
  end
  return nil
end

local hoverFrame = CreateFrame("Frame")
local hoverElapsed = 0
hoverFrame:SetScript("OnUpdate", function(self, dt)
  hoverElapsed = hoverElapsed + (dt or 0)
  if hoverElapsed < 0.05 then return end
  hoverElapsed = 0
  if (WorldMapFrame and WorldMapFrame:IsVisible()) or hoverShown then
    local ok, err = pcall(G.WorldHover)
    if not ok and not G.hoverErr then G.hoverErr = true; Print("erreur info-bulle carte : " .. tostring(err)) end
  end
end)


-- ------------------------------------------------------------------ minimap
local miniPins = {}
local function GetMiniPin(i)
  local p = miniPins[i]
  if not p then
    p = CreateFrame("Frame", nil, Minimap)
    p:SetWidth(12); p:SetHeight(12)
    p:SetFrameLevel(Minimap:GetFrameLevel() + 3)
    p.tex = p:CreateTexture(nil, "OVERLAY")
    p.tex:SetAllPoints(p)
    p.segs = {}
    miniPins[i] = p
  end
  return p
end

-- Deux niveaux de mise a jour :
--  * releve exact toutes les MINI_PERIOD s (position reelle, choix des points proches, style des ronds)
--  * a chaque image : on prolonge le deplacement du joueur (vitesse x cap) et on replace les ronds,
--    pour qu'ils defilent avec le fond de la minimap au lieu de sauter 4 fois par seconde.
local elapsed = 0
local track = nil   -- { px, py, c, zoom, indoors, size, rotate, pins = { {pin, ncx, ncy} } }

local function HidePins()
  for _, p in ipairs(miniPins) do p:Hide() end
end

local function StylePin(p, nd, d)
  if d.miniIcons then
    p:SetWidth(12); p:SetHeight(12)
    for _, sg in ipairs(p.segs) do sg:Hide() end
    p.tex:Show()
    p.tex:SetTexture(d.icons[nd.n] or DEFAULT_ICON[nd.t])
    p.tex:SetVertexColor(1, 1, 1, 1)
    return
  end
  -- anneau : petits disques opaques disposes en cercle, centre vide
  local c = DOT_COLOR[nd.t] or DOT_COLOR.ore
  local sz = d.miniSize
  local th = math.max(1, math.min(d.miniThick, math.floor(sz / 2)))
  local r = (sz - th) / 2
  local k = math.min(MAX_SEGS, math.max(8, math.ceil(math.pi * (sz - th) / math.max(1, th - 0.5))))
  p:SetWidth(sz); p:SetHeight(sz)
  p.tex:Hide()
  local al = d.miniAlpha / 100
  for j = 1, MAX_SEGS do
    local sg = p.segs[j]
    if not sg then
      sg = p:CreateTexture(nil, "OVERLAY")
      sg:SetTexture(DOT_TEXTURE)
      p.segs[j] = sg
    end
    if j <= k then
      local ang = (j - 1) / k * 2 * math.pi
      sg:SetWidth(th); sg:SetHeight(th)
      sg:ClearAllPoints()
      sg:SetPoint("CENTER", p, "CENTER", r * math.cos(ang), r * math.sin(ang))
      sg:SetVertexColor(c[1], c[2], c[3], al)
      sg:Show()
    else
      sg:Hide()
    end
  end
end

local function MiniRefresh()
  local d = EnsureDB()
  track = nil
  HidePins()
  if not d.mini or not Minimap:IsVisible() then return end
  local st = PlayerState()
  if not st or not st.cx then return end
  G.Calibrate(st)
  local list = d.nodes[st.key]
  if not list then return end
  local dims = CONTINENTS[st.c]
  if not dims then return end
  local zoom = Minimap:GetZoom() or 0
  local indoors = IsIndoors and IsIndoors() or false
  local diameter = (indoors and MINI_IN or MINI_OUT)[zoom]
  if not diameter then return end
  local reach = diameter / 2 + 80          -- marge : le joueur avance entre deux releves
  local pins = {}
  for _, nd in ipairs(list) do
    if nd.c == st.c and d.show[nd.t] then
      local ncx, ncy = nd.cx, nd.cy
      if not ncx then ncx, ncy = G.ToContinent(st.key, nd.x, nd.y) end
      if ncx then
        local sx, sy = (ncx - st.cx) * dims[1], (ncy - st.cy) * dims[2]
        if sx * sx + sy * sy <= reach * reach then
          if #pins >= 50 then break end
          local p = GetMiniPin(#pins + 1)
          StylePin(p, nd, d)
          pins[#pins + 1] = { p, ncx, ncy }
        end
      end
    end
  end
  track = { px = st.cx, py = st.cy, c = st.c, zoom = zoom, indoors = indoors, size = Minimap:GetWidth(),
            rotate = GetCVar and GetCVar("rotateMinimap") == "1", pins = pins, dims = dims }
end

local function MiniPlace(dt)
  local t = track
  if not t then return end
  local facing = GetPlayerFacing and GetPlayerFacing() or nil
  -- dead reckoning : vitesse (yards/s) dans la direction du regard
  local speed = GetUnitSpeed and GetUnitSpeed("player") or 0
  if speed and speed > 0 and facing and dt and dt > 0 then
    local dist = speed * math.min(dt, 0.1)
    t.px = t.px - math.sin(facing) * dist / t.dims[1]
    t.py = t.py - math.cos(facing) * dist / t.dims[2]
  end
  for _, e in ipairs(t.pins) do
    local p = e[1]
    local dx, dy = G.Project(t.px, t.py, e[2], e[3], t.c, t.zoom, t.indoors, t.size, facing, t.rotate)
    if dx then
      p:ClearAllPoints()
      p:SetPoint("CENTER", Minimap, "CENTER", dx, dy)
      p:Show()
    else
      p:Hide()
    end
  end
end

local miniFrame = CreateFrame("Frame")
miniFrame:SetScript("OnUpdate", function(self, dt)
  elapsed = elapsed + (dt or 0)
  if elapsed >= MINI_PERIOD then
    elapsed = 0
    MiniRefresh()
  end
  MiniPlace(dt)
end)

-- ------------------------------------------------------------------ fenetres
local frame, textFrame, textBox, countText

local function UpdateCount()
  if countText then countText:SetText(NodeCount() .. " points enregistres") end
end

local function ShowText(title, text, canApply)
  if not textFrame then
    textFrame = CreateFrame("Frame", "MithrilGatherTextFrame", UIParent)
    textFrame:SetWidth(460); textFrame:SetHeight(360)
    textFrame:SetPoint("CENTER", UIParent, "CENTER", 40, 0)
    textFrame:SetFrameStrata("DIALOG")
    textFrame:SetMovable(true); textFrame:EnableMouse(true)
    textFrame:RegisterForDrag("LeftButton")
    textFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    textFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    textFrame:SetBackdrop({
      bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
      edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
      tile = true, tileSize = 32, edgeSize = 32,
      insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    textFrame:Hide()
    textFrame.title = textFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    textFrame.title:SetPoint("TOP", textFrame, "TOP", 0, -18)
    local close = CreateFrame("Button", nil, textFrame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", textFrame, "TOPRIGHT", -6, -6)
    local scroll = CreateFrame("ScrollFrame", "MithrilGatherTextScroll", textFrame, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", textFrame, "TOPLEFT", 22, -48)
    scroll:SetWidth(390); scroll:SetHeight(250)
    textBox = CreateFrame("EditBox", "MithrilGatherTextBox", scroll)
    textBox:SetMultiLine(true)
    textBox:SetAutoFocus(false)
    textBox:SetFontObject(ChatFontNormal)
    textBox:SetWidth(380)
    textBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    scroll:SetScrollChild(textBox)
    textFrame.apply = CreateFrame("Button", nil, textFrame, "UIPanelButtonTemplate")
    textFrame.apply:SetWidth(140); textFrame.apply:SetHeight(24)
    textFrame.apply:SetPoint("BOTTOM", textFrame, "BOTTOM", 0, 20)
    textFrame.apply:SetText("Importer")
    textFrame.apply:SetScript("OnClick", function()
      local a, s, err = G.Import(textBox:GetText())
      if err then Print(err) else Print(a .. " nouveau(x) point(s), " .. s .. " deja connu(s).") end
      UpdateCount(); if RefreshWorld then RefreshWorld() end
    end)
    tinsert(UISpecialFrames, "MithrilGatherTextFrame")
  end
  textFrame.title:SetText(title)
  textBox:SetText(text or "")
  if canApply then textFrame.apply:Show() else textFrame.apply:Hide() end
  textFrame:Show()
  textBox:SetFocus()
  if not canApply then textBox:HighlightText() end
end

local function BuildUI()
  frame = CreateFrame("Frame", "MithrilGatherFrame", UIParent)
  frame:SetWidth(320); frame:SetHeight(602)
  frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  frame:SetFrameStrata("DIALOG")
  frame:SetMovable(true); frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
  frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
  })
  frame:Hide()
  local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOP", frame, "TOP", 0, -18)
  title:SetText("Recoltes")
  local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -6, -6)

  local d = EnsureDB()
  local y = -48
  local function Check(label, get, set)
    local cb = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, y)
    cb:SetChecked(get())
    local fs = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    fs:SetPoint("LEFT", cb, "RIGHT", 4, 0)
    fs:SetText(label)
    cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false); RefreshWorld() end)
    y = y - 26
  end
  for _, t in ipairs(TYPES) do
    Check(TYPE_LABEL[t], function() return EnsureDB().show[t] end, function(v) EnsureDB().show[t] = v end)
  end
  y = y - 8
  Check("Afficher sur la carte du monde", function() return EnsureDB().world end, function(v) EnsureDB().world = v end)
  Check("Afficher sur la minimap", function() return EnsureDB().mini end, function(v) EnsureDB().mini = v end)
  Check("Icones sur la minimap (sinon ronds transparents)", function() return EnsureDB().miniIcons end, function(v) EnsureDB().miniIcons = v end)


  local function Slider(label, name, minV, maxV, step, get, set)
    local sl = CreateFrame("Slider", name, frame, "OptionsSliderTemplate")
    sl:SetPoint("TOPLEFT", frame, "TOPLEFT", 30, y - 14)
    sl:SetWidth(240)
    sl:SetMinMaxValues(minV, maxV)
    sl:SetValueStep(step)
    sl:SetValue(get())
    local function Label(v)
      local t = _G[name .. "Text"]
      if t then t:SetText(label .. " : " .. math.floor(v + 0.5)) end
    end
    local lo, hi = _G[name .. "Low"], _G[name .. "High"]
    if lo then lo:SetText(minV) end
    if hi then hi:SetText(maxV) end
    Label(get())
    sl:SetScript("OnValueChanged", function(self, v) set(math.floor(v + 0.5)); Label(v) end)
    y = y - 40
  end
  Slider("Taille des icones (carte)", "MithrilGatherWorldSlider", 6, 24, 1,
    function() return EnsureDB().worldSize end, function(v) EnsureDB().worldSize = v; RefreshWorld() end)
  Slider("Taille des ronds", "MithrilGatherSizeSlider", 8, 30, 1,
    function() return EnsureDB().miniSize end, function(v) EnsureDB().miniSize = v end)
  Slider("Epaisseur du trait", "MithrilGatherThickSlider", 1, 8, 1,
    function() return EnsureDB().miniThick end, function(v) EnsureDB().miniThick = v end)
  Slider("Opacite des ronds (%)", "MithrilGatherAlphaSlider", 20, 100, 5,
    function() return EnsureDB().miniAlpha end, function(v) EnsureDB().miniAlpha = v end)

  countText = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
  countText:SetPoint("TOPLEFT", frame, "TOPLEFT", 26, y - 8)
  UpdateCount()

  local exp = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  exp:SetWidth(120); exp:SetHeight(24)
  exp:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 24, 22)
  exp:SetText("Exporter")
  exp:SetScript("OnClick", function() ShowText("Export des points", G.Export(), false) end)
  local imp = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  imp:SetWidth(120); imp:SetHeight(24)
  imp:SetPoint("LEFT", exp, "RIGHT", 10, 0)
  imp:SetText("Importer")
  imp:SetScript("OnClick", function() ShowText("Importer des points (colle ici)", "", true) end)
  local gm2 = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  gm2:SetWidth(254); gm2:SetHeight(24)
  gm2:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 24, 52)
  gm2:SetText("Importer GatherMate / GatherMate2")
  gm2:SetScript("OnClick", function() SlashCmdList["MITHRILGATHER"]("importgm2"); UpdateCount() end)
  tinsert(UISpecialFrames, "MithrilGatherFrame")
end

local function Toggle()
  if not frame then BuildUI() end
  UpdateCount()
  if frame:IsShown() then frame:Hide() else frame:Show() end
end

SLASH_MITHRILGATHER1 = "/mgather"
SlashCmdList["MITHRILGATHER"] = function(msg)
  EnsureDB()
  msg = string.lower(strtrim(msg or ""))
  if msg == "" then
    Toggle()
  elseif msg == "purge" then
    MithrilGatherDB.nodes = {}
    Print("Tous les points ont ete supprimes (les icones sont gardees).")
    RefreshWorld()
  elseif msg == "zones" then
    -- liste des identifiants de zones connus + resultat de SetMapByID pour les zones GatherMate inconnues (a copier/coller)
    if WorldMapFrame and WorldMapFrame:IsVisible() then Print("Ferme la carte du monde d'abord."); return end
    local byId = BuildZoneIndex()
    local lines = { "Identifiants connus (id = carte, continent) :" }
    local ids = {}
    for id in pairs(byId) do ids[#ids + 1] = id end
    table.sort(ids)
    for _, id in ipairs(ids) do lines[#lines + 1] = id .. " = " .. byId[id].key .. " (c" .. byId[id].c .. ")" end
    lines[#lines + 1] = ""
    lines[#lines + 1] = "Zones GatherMate non connues :"
    for _, src in ipairs(FindSources()) do
      local db = _G[src.global]
      local store = rawget(db, "__gm2_base_storage") or db
      for zone, data in pairs(store) do
        local gm1known = not (src.gm2 or MaxCoord(store) >= 1e9) and type(zone) == "number" and GM1_ZONES[zone]
        if type(data) == "table" and not gm1known and not ((src.gm2 or MaxCoord(store) >= 1e9) and byId[zone]) then
          local n = 0
          for _ in pairs(data) do n = n + 1 end
          -- contenu de la zone : noms des points les plus frequents + etendue des coordonnees (aide a identifier la zone)
          local resolve = NameResolver()
          local gm2 = src.gm2 or MaxCoord(store) >= 1e9
          local cnt, minx, maxx, miny, maxy = {}, 9, -9, 9, -9
          for coord, id in pairs(data) do
            if type(coord) == "number" and type(id) == "number" then
              local x, y = DecodeCoord(coord, gm2)
              if x < minx then minx = x end
              if x > maxx then maxx = x end
              if y < miny then miny = y end
              if y > maxy then maxy = y end
              local nm = resolve(KIND_BY_TYPE[src.t], id) or ("#" .. id)
              cnt[nm] = (cnt[nm] or 0) + 1
            end
          end
          local arr = {}
          for nm, c in pairs(cnt) do arr[#arr + 1] = { nm, c } end
          table.sort(arr, function(u, v) return u[2] > v[2] end)
          local top = {}
          for i = 1, math.min(5, #arr) do top[#top + 1] = arr[i][1] .. " x" .. arr[i][2] end
          lines[#lines + 1] = src.global .. " zone " .. tostring(zone) .. " (" .. n .. " pts) : " .. table.concat(top, ", ") ..
            string.format(" | x %.2f-%.2f y %.2f-%.2f", minx, maxx, miny, maxy)
        end
      end
    end
    if SetMapToCurrentZone then SetMapToCurrentZone() end
    ShowText("Zones", table.concat(lines, "\n"), false)
  elseif msg == "scangm" then
    for _, l in ipairs(G.ScanGM()) do Print(l) end
  elseif msg == "importgm2" or msg == "importgm" then
    local a, b, c, bad, unk, resolved, fixed = G.ImportGM2()
    if not a then
      Print(b)
    else
      if fixed and fixed > 0 then
        Print(fixed .. " point(s) importes dans la mauvaise zone par une ancienne version ont ete deplaces vers la bonne zone.")
      end
      Print(a .. " point(s) importe(s) depuis GatherMate, " .. b .. " deja connu(s)" ..
        ((c and c > 0) and (", " .. c .. " zone(s) non reconnue(s) ignoree(s)") or "") ..
        ((bad and bad > 0) and (", " .. bad .. " point(s) invalide(s)") or "") .. ".")
      if resolved and next(resolved) then
        local r = {}
        for id, key in pairs(resolved) do r[#r + 1] = id .. "=" .. key end
        table.sort(r)
        Print("Zones retrouvees via leur identifiant : " .. table.concat(r, ", "))
      end
      if unk and next(unk) then
        local arr = {}
        for z, n in pairs(unk) do arr[#arr + 1] = { z, n } end
        table.sort(arr, function(x, y) return x[2] > y[2] end)
        local lost = 0
        for _, e in ipairs(arr) do lost = lost + e[2] end
        local parts = {}
        for i = 1, math.min(8, #arr) do parts[#parts + 1] = arr[i][1] .. " (" .. arr[i][2] .. ")" end
        Print("Non importes (" .. lost .. " points, zones inconnues) : " .. table.concat(parts, ", ") ..
          (#arr > 8 and ", ..." or ""))
      end
      Print("Sur la minimap, les points importes apparaissent dans une zone apres t'y etre deplace un peu (calibrage).")
      RefreshWorld()
    end
  elseif msg == "debug" then
    local st = PlayerState()
    Print(st and ("Zone " .. st.key .. " continent " .. st.c .. " pos " .. string.format("%.4f %.4f", st.x, st.y) ..
      (st.cx and (" continent " .. string.format("%.5f %.5f", st.cx, st.cy)) or " (position continent indisponible)")) or "Position indisponible ici.")
    Print(NodeCount() .. " points. Sorts : " .. (next(spellType) and "reconnus" or "NON reconnus (GetSpellInfo)"))
    Print("Minimap zoom " .. tostring(Minimap:GetZoom()) .. ", rotation " .. tostring(GetCVar and GetCVar("rotateMinimap")))
  else
    Print("Commandes : /mgather | importgm | scangm | purge | debug")
  end
end
