-- MithrilGather : releve de points de recolte (minerais, herbes, gaz).
--  * Chaque recolte reussie est enregistree (zone + position).
--  * Les points s'affichent sur la carte du monde et sur la minimap.
--  * /mgather : fenetre de reglages, export et import (copier-coller entre vendeurs).
-- Les points se remplissent au fil de tes recoltes : au debut, il n'y a rien a afficher.

local TAG = "|cffd4a017MithrilGather|r "
local MERGE_DIST = 0.004          -- fusion de deux points identiques (unites de carte)
local MINI_PERIOD = 0.25          -- secondes entre deux mises a jour de la minimap

-- Taille des continents en yards (largeur, hauteur) : valeurs de memoire, voir /mgather debug
local CONTINENTS = {
  [1] = { 36798.56, 24532.39 },   -- Kalimdor
  [2] = { 37714.67, 25143.78 },   -- Royaumes de l'Est
  [3] = { 17463.5, 11642.3 },     -- Outreterre
  [4] = { 17751.3, 11834.2 },     -- Norfendre
}
-- Diametre de la minimap en yards selon le zoom
local MINI_OUT = { [0] = 466.67, [1] = 400, [2] = 333.33, [3] = 266.67, [4] = 200, [5] = 133.33 }
local MINI_IN  = { [0] = 300, [1] = 240, [2] = 180, [3] = 120, [4] = 80, [5] = 50 }

local SPELLS = { [2575] = "ore", [2366] = "herb", [30427] = "gas" }   -- Minage, Cueillette, Extraction de gaz
local TYPES = { "ore", "herb", "gas" }
local TYPE_LABEL = { ore = "Minerais", herb = "Herbes", gas = "Gaz" }
local DOT_TEXTURE = "Interface\\CharacterFrame\\TempPortraitAlphaMask"   -- disque plein, rond garanti
local DOT_COLOR = {
  ore  = { 1.0, 0.15, 0.15 },
  herb = { 1.0, 1.0, 0.2 },
  gas  = { 0.3, 0.9, 1.0 },
}
local MAX_SEGS = 16
local DEFAULT_ICON = {
  ore = "Interface\\Icons\\INV_Ore_Copper_01",
  herb = "Interface\\Icons\\INV_Misc_Herb_07",
  gas = "Interface\\Icons\\INV_Elemental_Mote_Air01",
}

MithrilGatherDB = MithrilGatherDB or {}
local G = {}
MithrilGather = G

local function Print(msg) DEFAULT_CHAT_FRAME:AddMessage(TAG .. tostring(msg)) end

-- Les variables sauvegardees arrivent APRES ce fichier : on complete la base a chaque entree.
local function EnsureDB()
  MithrilGatherDB = MithrilGatherDB or {}
  local d = MithrilGatherDB
  d.nodes = d.nodes or {}          -- [cleZone] = { {x,y,cx,cy,c,n,t}, ... }
  d.cal = d.cal or {}             -- [cleZone] = calibration zone -> continent (pour les points importes)
  d.icons = d.icons or {}          -- [nomDuPoint] = texture
  d.show = d.show or { ore = true, herb = true, gas = true }
  if d.world == nil then d.world = true end
  if d.mini == nil then d.mini = true end
  if type(d.miniSize) ~= "number" then d.miniSize = 14 end
  if type(d.miniAlpha) ~= "number" then d.miniAlpha = 90 end   -- pourcentage
  -- migration unique : anciennes versions stockaient mini=false / miniIcons=true
  if (d.ver or 0) < 4 then d.mini = true; d.miniIcons = false; d.miniSize = 14; d.miniAlpha = 90 end
  -- v5 : les anciennes icones venaient parfois d'une gemme du butin -> on les reapprend
  if (d.ver or 0) < 5 then d.icons = {} end
  d.ver = 5
  if d.miniIcons == nil then d.miniIcons = false end   -- false = ronds transparents (ne cachent pas le point reel)
  return d
end
EnsureDB()

local spellType = {}              -- nom localise du sort -> type
local function BuildSpellNames()
  for id, t in pairs(SPELLS) do
    local name = GetSpellInfo and GetSpellInfo(id)
    if name then spellType[name] = t end
  end
end

-- ------------------------------------------------------------------ donnees
local function NodeCount()
  local n = 0
  for _, list in pairs(EnsureDB().nodes) do n = n + #list end
  return n
end

-- Ajoute un point (fusionne avec un point proche du meme nom). Renvoie true si c'est un nouveau point.
function G.Add(key, c, name, t, x, y, cx, cy)
  local d = EnsureDB()
  local list = d.nodes[key]
  if not list then list = {}; d.nodes[key] = list end
  for _, nd in ipairs(list) do
    if nd.n == name and (nd.x - x) ^ 2 + (nd.y - y) ^ 2 < MERGE_DIST ^ 2 then
      if cx and not nd.cx then nd.cx, nd.cy = cx, cy end
      return false
    end
  end
  table.insert(list, { x = x, y = y, cx = cx, cy = cy, c = c, n = name, t = t })
  return true
end

local function Round(v) return math.floor(v * 100000 + 0.5) / 100000 end

-- Export texte : une ligne par point, plus les icones connues
function G.Export()
  local d = EnsureDB()
  local out = { "MITHRILGATHER1" }
  for name, tex in pairs(d.icons) do
    table.insert(out, "I|" .. name .. "|" .. tex)
  end
  for key, list in pairs(d.nodes) do
    for _, nd in ipairs(list) do
      table.insert(out, table.concat({ "N", key, nd.c or 0, nd.t, nd.n, Round(nd.x), Round(nd.y),
        nd.cx and Round(nd.cx) or "", nd.cy and Round(nd.cy) or "" }, "|"))
    end
  end
  return table.concat(out, "\n")
end

-- Import : fusionne avec les points existants. Renvoie (nouveaux, ignores)
function G.Import(text)
  local d = EnsureDB()
  local added, skipped = 0, 0
  local first = true
  for line in string.gmatch(text or "", "[^\r\n]+") do
    if first then
      first = false
      if not string.find(line, "^MITHRILGATHER1") then return 0, 0, "Format inconnu (la premiere ligne doit etre MITHRILGATHER1)." end
    else
      local f = {}
      for part in string.gmatch(line .. "|", "([^|]*)|") do table.insert(f, part) end
      if f[1] == "I" and f[2] and f[3] and f[2] ~= "" then
        if not d.icons[f[2]] then d.icons[f[2]] = f[3] end
      elseif f[1] == "N" and #f >= 7 then
        local x, y = tonumber(f[6]), tonumber(f[7])
        local t = f[4]
        if x and y and DEFAULT_ICON[t] and f[2] ~= "" and f[5] ~= "" then
          if G.Add(f[2], tonumber(f[3]), f[5], t, x, y, tonumber(f[8]), tonumber(f[9])) then
            added = added + 1
          else
            skipped = skipped + 1
          end
        end
      end
    end
  end
  return added, skipped
end

-- ------------------------------------------------------------------ calibration zone -> continent
-- La minimap a besoin de coordonnees continent. Les points importes n'ont que des coordonnees de
-- zone : on apprend la transformation de chaque zone quand tu t'y deplaces (une ancre + l'echantillon
-- le plus eloigne sur chaque axe).
function G.Calibrate(st)
  if not st or not st.cx then return end
  local cal = EnsureDB().cal[st.key]
  if not cal then
    EnsureDB().cal[st.key] = { c = st.c, ax = st.x, ay = st.y, acx = st.cx, acy = st.cy }
    return
  end
  local dx = math.abs(st.x - cal.ax)
  if dx > 0.02 and dx > (cal.dxs or 0) then
    cal.sx = (st.cx - cal.acx) / (st.x - cal.ax); cal.dxs = dx
  end
  local dy = math.abs(st.y - cal.ay)
  if dy > 0.02 and dy > (cal.dys or 0) then
    cal.sy = (st.cy - cal.acy) / (st.y - cal.ay); cal.dys = dy
  end
end

-- Convertit une position de zone en position continent (nil tant que la zone n'est pas calibree)
function G.ToContinent(key, x, y)
  local cal = EnsureDB().cal[key]
  if cal and cal.sx and cal.sy then
    return cal.acx + (x - cal.ax) * cal.sx, cal.acy + (y - cal.ay) * cal.sy
  end
  return nil
end

-- ------------------------------------------------------------------ import GatherMate / GatherMate2
-- Lit les donnees des add-ons GatherMate2 (variables GatherMate2MineDB / HerbDB / GasDB) et GatherMate 1
-- (variables dont le nom commence par GatherMate et contient Mine/Mining, Herb ou Gas).
-- Structure attendue : [zone][coord] = idDuPoint, avec la zone en identifiant de carte OU en nom.
-- Codage de coord : GatherMate2 = x*10000*1000000 + y*10000*100 + etage ; GatherMate 1 = x*10000*10000 + y*10000
-- (detecte automatiquement selon la taille des valeurs).
local KIND_BY_TYPE = { ore = "Mining", herb = "Herb Gathering", gas = "Extract Gas" }

local function SourceType(name)
  local low = string.lower(name)
  if string.find(low, "mine") or string.find(low, "mining") then return "ore" end
  if string.find(low, "herb") then return "herb" end
  if string.find(low, "gas") then return "gas" end
  return nil
end

-- Liste des tables de donnees GatherMate presentes : { {global=, t=, gm2=bool}, ... }
local function FindSources()
  local out = {}
  for name, v in pairs(_G) do
    if type(name) == "string" and type(v) == "table" and string.find(name, "^GatherMate") and string.find(name, "DB$") then
      local t = SourceType(name)
      if t and not string.find(name, "Fish") and not string.find(name, "Treasure") then
        table.insert(out, { global = name, t = t, gm2 = (string.find(name, "^GatherMate2") ~= nil) })
      end
    end
  end
  table.sort(out, function(a, b) return a.global < b.global end)
  return out
end

-- Acces aux noms localises des points via l'add-on lui-meme (GatherMate2 ou GatherMate 1), si possible
local function NameResolver()
  local candidates = {}
  if LibStub then
    local ok, AceAddon = pcall(LibStub, "AceAddon-3.0", true)
    if ok and AceAddon and AceAddon.GetAddon then
      local ok2, addon = pcall(AceAddon.GetAddon, AceAddon, "GatherMate2", true)
      if ok2 and addon then table.insert(candidates, addon) end
    end
  end
  if type(_G.GatherMate) == "table" then table.insert(candidates, _G.GatherMate) end
  return function(kind, id)
    for _, gm in ipairs(candidates) do
      local name
      if type(gm.reverseNodeIDs) == "table" and gm.reverseNodeIDs[kind] then name = gm.reverseNodeIDs[kind][id] end
      if not name and type(gm.GetNameForNode) == "function" then
        local ok, r = pcall(gm.GetNameForNode, gm, kind, id)
        if ok then name = r end
      end
      if type(name) == "string" and name ~= "" then return name end
    end
    return nil
  end
end

-- Table idDeZone / nomDeZone -> {cle, continent}, construite avec les cartes du jeu (carte du monde fermee)
local function BuildZoneIndex()
  local byId, byName = {}, {}
  if not (GetMapContinents and GetMapZones and SetMapZoom) then return byId, byName end
  local conts = { GetMapContinents() }
  for c = 1, #conts do
    local zones = { GetMapZones(c) }
    for z = 1, #zones do
      SetMapZoom(c, z)
      local key = GetMapInfo()
      if key and key ~= "" then
        if GetCurrentMapAreaID then byId[GetCurrentMapAreaID()] = { key = key, c = c } end
        byName[zones[z]] = { key = key, c = c }
        byName[key] = { key = key, c = c }
      end
    end
  end
  SetMapToCurrentZone()
  return byId, byName
end

local function DecodeCoord(coord, gm2style)
  if gm2style then
    return math.floor(coord / 1000000) / 10000, math.floor(coord % 1000000 / 100) / 10000
  end
  return math.floor(coord / 10000) / 10000, (coord % 10000) / 10000
end

local function MaxCoord(store)
  local m = 0
  for _, data in pairs(store) do
    if type(data) == "table" then
      for coord in pairs(data) do if type(coord) == "number" and coord > m then m = coord end end
    end
  end
  return m
end

function G.ImportGM2()
  if WorldMapFrame and WorldMapFrame:IsVisible() then return nil, "Ferme la carte du monde avant d'importer." end
  local sources = FindSources()
  if #sources == 0 then
    return nil, "Donnees GatherMate introuvables : installe et active GatherMate ou GatherMate2, puis /reload et reessaie."
  end
  local d = EnsureDB()
  local resolve = NameResolver()
  local byId, byName = BuildZoneIndex()
  local seen = {}
  local function cell(key, name, x, y) return key .. "|" .. name .. "|" .. math.floor(x * 250) .. "|" .. math.floor(y * 250) end
  for key, list in pairs(d.nodes) do
    for _, nd in ipairs(list) do seen[cell(key, nd.n, nd.x, nd.y)] = true end
  end
  local added, dup, bad = 0, 0, 0
  local unknownZone = {}
  for _, src in ipairs(sources) do
    local db = _G[src.global]
    local store = rawget(db, "__gm2_base_storage") or db
    local gm2style = src.gm2 or MaxCoord(store) >= 1e9
    for zone, data in pairs(store) do
      if type(data) == "table" then
        local info = byId[zone] or byName[zone]
        if not info then
          unknownZone[tostring(zone)] = true
        else
          for coord, id in pairs(data) do
            if type(coord) == "number" and type(id) == "number" then
              local x, y = DecodeCoord(coord, gm2style)
              if x <= 0 or y <= 0 or x >= 1 or y >= 1 then
                bad = bad + 1
              else
                local name = resolve(KIND_BY_TYPE[src.t], id) or (TYPE_LABEL[src.t] .. " #" .. id)
                local k = cell(info.key, name, x, y)
                if seen[k] then
                  dup = dup + 1
                else
                  seen[k] = true
                  local list = d.nodes[info.key]
                  if not list then list = {}; d.nodes[info.key] = list end
                  table.insert(list, { x = x, y = y, c = info.c, n = name, t = src.t })
                  added = added + 1
                end
              end
            end
          end
        end
      end
    end
  end
  local nUnknown = 0
  for _ in pairs(unknownZone) do nUnknown = nUnknown + 1 end
  return added, dup, nUnknown, bad
end

-- Diagnostic : decrit ce qui est present (aide a adapter l'import a une version precise)
function G.ScanGM()
  local lines = {}
  local sources = FindSources()
  if #sources == 0 then return { "Aucune table de donnees GatherMate trouvee (add-on non charge ?)." } end
  for _, src in ipairs(sources) do
    local db = _G[src.global]
    local store = rawget(db, "__gm2_base_storage") or db
    local zones, nodes = 0, 0
    local zk, ck, cv
    for zone, data in pairs(store) do
      if type(data) == "table" then
        zones = zones + 1
        if not zk then zk = zone end
        for coord, id in pairs(data) do
          nodes = nodes + 1
          if not ck then ck, cv = coord, id end
        end
      end
    end
    table.insert(lines, string.format("%s : %d zones, %d points, exemple zone=%s (%s) coord=%s id=%s",
      src.global, zones, nodes, tostring(zk), type(zk), tostring(ck), tostring(cv)))
  end
  return lines
end

-- ------------------------------------------------------------------ position du joueur
-- Renvoie cleZone, continent, x, y (zone), cx, cy (continent) ou nil
local lastState
local function PlayerState()
  if WorldMapFrame and WorldMapFrame:IsVisible() then return lastState end
  SetMapToCurrentZone()
  local c, z = GetCurrentMapContinent(), GetCurrentMapZone()
  if not c or c < 1 or not z or z < 1 then lastState = nil; return nil end
  local x, y = GetPlayerMapPosition("player")
  if not x or (x == 0 and y == 0) then lastState = nil; return nil end
  local key = GetMapInfo()
  if not key or key == "" then lastState = nil; return nil end
  local cx, cy
  SetMapZoom(c)
  cx, cy = GetPlayerMapPosition("player")
  SetMapToCurrentZone()
  if not cx or (cx == 0 and cy == 0) then cx, cy = nil, nil end
  lastState = { key = key, c = c, x = x, y = y, cx = cx, cy = cy }
  return lastState
end

-- Projection minimap : renvoie (dx, dy) en pixels depuis le centre, ou nil si hors de portee
function G.Project(px, py, nx, ny, cont, zoom, indoors, mapSize, facing, rotate)
  local dims = CONTINENTS[cont]
  if not dims then return nil end
  local diameter = (indoors and MINI_IN or MINI_OUT)[zoom]
  if not diameter then return nil end
  local sx = (nx - px) * dims[1]            -- yards vers l'est
  local sy = -(ny - py) * dims[2]           -- yards vers le nord
  if rotate and facing then
    local cf, sf = math.cos(facing), math.sin(facing)
    sx, sy = sx * cf + sy * sf, -sx * sf + sy * cf
  end
  if sx * sx + sy * sy > (diameter / 2) ^ 2 then return nil end
  local k = mapSize / diameter
  return sx * k, sy * k
end

-- ------------------------------------------------------------------ enregistrement
-- mots sans valeur pour comparer un nom de filon ("Filon de cuivre") a celui du minerai ("Minerai de cuivre")
local STOP = { filon = true, riche = true, gisement = true, depot = true, ["dépôt"] = true, amas = true,
               veine = true, minerai = true, de = true, du = true, des = true, la = true, le = true,
               les = true, ["d"] = true, ["l"] = true, vein = true, deposit = true, rich = true, ore = true }
local function Tokens(name)
  local t = {}
  for w in string.gmatch(string.lower(tostring(name or "")), "[^%s'%-%.,]+") do
    if #w > 2 and not STOP[w] then t[w] = true end
  end
  return t
end
-- vrai si les deux noms partagent un mot significatif (cuivre, mithril, saronite, lotus...)
function G.NameMatches(nodeName, itemName)
  if not nodeName or not itemName then return false end
  local a = Tokens(nodeName)
  for w in pairs(Tokens(itemName)) do
    if a[w] then return true end
  end
  return false
end

local pending, lastNode
local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("UNIT_SPELLCAST_SENT")
ev:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
ev:RegisterEvent("UNIT_SPELLCAST_FAILED")
ev:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
ev:RegisterEvent("LOOT_OPENED")
ev:RegisterEvent("WORLD_MAP_UPDATE")

local RefreshWorld

ev:SetScript("OnEvent", function(self, event, a1, a2, a3, a4)
  if event == "PLAYER_LOGIN" then
    EnsureDB(); BuildSpellNames()
    Print("charge. /mgather pour les reglages. Les points se remplissent au fil de tes recoltes.")
  elseif event == "UNIT_SPELLCAST_SENT" then
    -- a1 = unit, a2 = sort, a3 = rang, a4 = cible
    if a1 == "player" and spellType[a2] and a4 and a4 ~= "" then
      local st = PlayerState()
      if st then pending = { name = a4, spell = a2, t = spellType[a2], st = st, at = GetTime() } else pending = nil end
    end
  elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
    if a1 == "player" and pending and a2 == pending.spell and (GetTime() - pending.at) < 30 then
      local p = pending; pending = nil
      G.Calibrate(p.st)
      local isNew = G.Add(p.st.key, p.st.c, p.name, p.t, p.st.x, p.st.y, p.st.cx, p.st.cy)
      lastNode = { name = p.name, at = GetTime() }
      if isNew then Print("Nouveau point : " .. p.name) end
      if RefreshWorld then RefreshWorld() end
    end
  elseif event == "UNIT_SPELLCAST_FAILED" or event == "UNIT_SPELLCAST_INTERRUPTED" then
    if a1 == "player" then pending = nil end
  elseif event == "LOOT_OPENED" then
    -- l'icone du point = celle du butin dont le nom correspond au filon / a la plante
    -- (pas le premier objet : un filon donne aussi des gemmes, qui ne doivent pas servir d'icone)
    if lastNode and (GetTime() - lastNode.at) < 15 then
      local d = EnsureDB()
      if GetLootSlotInfo then
        local n = (GetNumLootItems and GetNumLootItems()) or 1
        for slot = 1, n do
          local tex, itemName = GetLootSlotInfo(slot)
          if tex and G.NameMatches(lastNode.name, itemName) then
            d.icons[lastNode.name] = tex
            if RefreshWorld then RefreshWorld() end
            break
          end
        end
      end
      lastNode = nil
    end
  elseif event == "WORLD_MAP_UPDATE" then
    if RefreshWorld then RefreshWorld() end
  end
end)

-- ------------------------------------------------------------------ carte du monde
local worldPins = {}
local function GetPin(i)
  local p = worldPins[i]
  if not p then
    p = CreateFrame("Button", nil, WorldMapButton)
    p:SetWidth(14); p:SetHeight(14)
    p:SetFrameLevel(WorldMapButton:GetFrameLevel() + 6)
    p.tex = p:CreateTexture(nil, "OVERLAY")
    p.tex:SetAllPoints(p)
    p:SetScript("OnEnter", function(self)
      GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
      GameTooltip:AddLine(self.nodeName or "?")
      GameTooltip:Show()
    end)
    p:SetScript("OnLeave", function() GameTooltip:Hide() end)
    worldPins[i] = p
  end
  return p
end

RefreshWorld = function()
  if not (WorldMapFrame and WorldMapButton) then return end
  for _, p in ipairs(worldPins) do p:Hide() end
  local d = EnsureDB()
  if not d.world or not WorldMapFrame:IsVisible() then return end
  if (GetCurrentMapZone() or 0) < 1 then return end
  local key = GetMapInfo()
  local list = key and d.nodes[key]
  if not list then return end
  local w, h = WorldMapButton:GetWidth(), WorldMapButton:GetHeight()
  local n = 0
  for _, nd in ipairs(list) do
    if d.show[nd.t] and n < 1500 then
      n = n + 1
      local p = GetPin(n)
      p.nodeName = nd.n
      p.tex:SetTexture(d.icons[nd.n] or DEFAULT_ICON[nd.t])
      p:ClearAllPoints()
      p:SetPoint("CENTER", WorldMapButton, "TOPLEFT", nd.x * w, -nd.y * h)
      p:Show()
    end
  end
end

-- ------------------------------------------------------------------ minimap
local miniPins = {}
local function GetMiniPin(i)
  local p = miniPins[i]
  if not p then
    p = CreateFrame("Frame", nil, Minimap)
    p:SetWidth(12); p:SetHeight(12)
    p:SetFrameLevel(Minimap:GetFrameLevel() + 3)
    p.tex = p:CreateTexture(nil, "OVERLAY")
    p.tex:SetAllPoints(p)
    p.segs = {}
    miniPins[i] = p
  end
  return p
end

local elapsed = 0
local miniFrame = CreateFrame("Frame")
miniFrame:SetScript("OnUpdate", function(self, dt)
  elapsed = elapsed + (dt or 0)
  if elapsed < MINI_PERIOD then return end
  elapsed = 0
  local d = EnsureDB()
  for _, p in ipairs(miniPins) do p:Hide() end
  if not d.mini or not Minimap:IsVisible() then return end
  local st = PlayerState()
  if not st or not st.cx then return end
  G.Calibrate(st)
  local list = d.nodes[st.key]
  if not list then return end
  local zoom = Minimap:GetZoom() or 0
  local indoors = IsIndoors and IsIndoors() or false
  local rotate = GetCVar and GetCVar("rotateMinimap") == "1"
  local facing = GetPlayerFacing and GetPlayerFacing() or nil
  local size = Minimap:GetWidth()
  local n = 0
  for _, nd in ipairs(list) do
    if nd.c == st.c and d.show[nd.t] then
      local ncx, ncy = nd.cx, nd.cy
      if not ncx then ncx, ncy = G.ToContinent(st.key, nd.x, nd.y) end
      local dx, dy
      if ncx then dx, dy = G.Project(st.cx, st.cy, ncx, ncy, st.c, zoom, indoors, size, facing, rotate) end
      if dx then
        n = n + 1
        if n > 50 then break end
        local p = GetMiniPin(n)
        if d.miniIcons then
          p:SetWidth(12); p:SetHeight(12)
          for _, sg in ipairs(p.segs) do sg:Hide() end
          p.tex:Show()
          p.tex:SetTexture(d.icons[nd.n] or DEFAULT_ICON[nd.t])
          p.tex:SetVertexColor(1, 1, 1, 1)
        else
          -- rond transparent : on voit toujours le vrai point (minerai, herbe) a travers
          local c = DOT_COLOR[nd.t] or DOT_COLOR.ore
          -- anneau : petits disques opaques disposes en cercle, centre vide
          local sz = d.miniSize
          local th = math.max(2, math.floor(sz / 5 + 0.5))
          local r = (sz - th) / 2
          local k = math.min(MAX_SEGS, math.max(8, math.ceil(math.pi * sz / th)))
          p:SetWidth(sz); p:SetHeight(sz)
          p.tex:Hide()
          local al = d.miniAlpha / 100
          for j = 1, MAX_SEGS do
            local sg = p.segs[j]
            if not sg then
              sg = p:CreateTexture(nil, "OVERLAY")
              sg:SetTexture(DOT_TEXTURE)
              p.segs[j] = sg
            end
            if j <= k then
              local ang = (j - 1) / k * 2 * math.pi
              sg:SetWidth(th); sg:SetHeight(th)
              sg:ClearAllPoints()
              sg:SetPoint("CENTER", p, "CENTER", r * math.cos(ang), r * math.sin(ang))
              sg:SetVertexColor(c[1], c[2], c[3], al)
              sg:Show()
            else
              sg:Hide()
            end
          end
        end
        p:ClearAllPoints()
        p:SetPoint("CENTER", Minimap, "CENTER", dx, dy)
        p:Show()
      end
    end
  end
end)

-- ------------------------------------------------------------------ fenetres
local frame, textFrame, textBox, countText

local function UpdateCount()
  if countText then countText:SetText(NodeCount() .. " points enregistres") end
end

local function ShowText(title, text, canApply)
  if not textFrame then
    textFrame = CreateFrame("Frame", "MithrilGatherTextFrame", UIParent)
    textFrame:SetWidth(460); textFrame:SetHeight(360)
    textFrame:SetPoint("CENTER", UIParent, "CENTER", 40, 0)
    textFrame:SetFrameStrata("DIALOG")
    textFrame:SetMovable(true); textFrame:EnableMouse(true)
    textFrame:RegisterForDrag("LeftButton")
    textFrame:SetScript("OnDragStart", function(self) self:StartMoving() end)
    textFrame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    textFrame:SetBackdrop({
      bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
      edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
      tile = true, tileSize = 32, edgeSize = 32,
      insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    textFrame:Hide()
    textFrame.title = textFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    textFrame.title:SetPoint("TOP", textFrame, "TOP", 0, -18)
    local close = CreateFrame("Button", nil, textFrame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", textFrame, "TOPRIGHT", -6, -6)
    local scroll = CreateFrame("ScrollFrame", "MithrilGatherTextScroll", textFrame, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", textFrame, "TOPLEFT", 22, -48)
    scroll:SetWidth(390); scroll:SetHeight(250)
    textBox = CreateFrame("EditBox", "MithrilGatherTextBox", scroll)
    textBox:SetMultiLine(true)
    textBox:SetAutoFocus(false)
    textBox:SetFontObject(ChatFontNormal)
    textBox:SetWidth(380)
    textBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    scroll:SetScrollChild(textBox)
    textFrame.apply = CreateFrame("Button", nil, textFrame, "UIPanelButtonTemplate")
    textFrame.apply:SetWidth(140); textFrame.apply:SetHeight(24)
    textFrame.apply:SetPoint("BOTTOM", textFrame, "BOTTOM", 0, 20)
    textFrame.apply:SetText("Importer")
    textFrame.apply:SetScript("OnClick", function()
      local a, s, err = G.Import(textBox:GetText())
      if err then Print(err) else Print(a .. " nouveau(x) point(s), " .. s .. " deja connu(s).") end
      UpdateCount(); if RefreshWorld then RefreshWorld() end
    end)
    tinsert(UISpecialFrames, "MithrilGatherTextFrame")
  end
  textFrame.title:SetText(title)
  textBox:SetText(text or "")
  if canApply then textFrame.apply:Show() else textFrame.apply:Hide() end
  textFrame:Show()
  textBox:SetFocus()
  if not canApply then textBox:HighlightText() end
end

local function BuildUI()
  frame = CreateFrame("Frame", "MithrilGatherFrame", UIParent)
  frame:SetWidth(320); frame:SetHeight(470)
  frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  frame:SetFrameStrata("DIALOG")
  frame:SetMovable(true); frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
  frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
  })
  frame:Hide()
  local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOP", frame, "TOP", 0, -18)
  title:SetText("Recoltes")
  local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -6, -6)

  local d = EnsureDB()
  local y = -48
  local function Check(label, get, set)
    local cb = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, y)
    cb:SetChecked(get())
    local fs = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    fs:SetPoint("LEFT", cb, "RIGHT", 4, 0)
    fs:SetText(label)
    cb:SetScript("OnClick", function(self) set(self:GetChecked() and true or false); RefreshWorld() end)
    y = y - 26
  end
  for _, t in ipairs(TYPES) do
    Check(TYPE_LABEL[t], function() return EnsureDB().show[t] end, function(v) EnsureDB().show[t] = v end)
  end
  y = y - 8
  Check("Afficher sur la carte du monde", function() return EnsureDB().world end, function(v) EnsureDB().world = v end)
  Check("Afficher sur la minimap", function() return EnsureDB().mini end, function(v) EnsureDB().mini = v end)
  Check("Icones sur la minimap (sinon ronds transparents)", function() return EnsureDB().miniIcons end, function(v) EnsureDB().miniIcons = v end)


  local function Slider(label, name, minV, maxV, step, get, set)
    local sl = CreateFrame("Slider", name, frame, "OptionsSliderTemplate")
    sl:SetPoint("TOPLEFT", frame, "TOPLEFT", 30, y - 14)
    sl:SetWidth(240)
    sl:SetMinMaxValues(minV, maxV)
    sl:SetValueStep(step)
    sl:SetValue(get())
    local function Label(v)
      local t = _G[name .. "Text"]
      if t then t:SetText(label .. " : " .. math.floor(v + 0.5)) end
    end
    local lo, hi = _G[name .. "Low"], _G[name .. "High"]
    if lo then lo:SetText(minV) end
    if hi then hi:SetText(maxV) end
    Label(get())
    sl:SetScript("OnValueChanged", function(self, v) set(math.floor(v + 0.5)); Label(v) end)
    y = y - 40
  end
  Slider("Taille des ronds", "MithrilGatherSizeSlider", 8, 30, 1,
    function() return EnsureDB().miniSize end, function(v) EnsureDB().miniSize = v end)
  Slider("Opacite des ronds (%)", "MithrilGatherAlphaSlider", 20, 100, 5,
    function() return EnsureDB().miniAlpha end, function(v) EnsureDB().miniAlpha = v end)

  countText = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
  countText:SetPoint("TOPLEFT", frame, "TOPLEFT", 26, y - 8)
  UpdateCount()

  local exp = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  exp:SetWidth(120); exp:SetHeight(24)
  exp:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 24, 22)
  exp:SetText("Exporter")
  exp:SetScript("OnClick", function() ShowText("Export des points", G.Export(), false) end)
  local imp = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  imp:SetWidth(120); imp:SetHeight(24)
  imp:SetPoint("LEFT", exp, "RIGHT", 10, 0)
  imp:SetText("Importer")
  imp:SetScript("OnClick", function() ShowText("Importer des points (colle ici)", "", true) end)
  local gm2 = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  gm2:SetWidth(254); gm2:SetHeight(24)
  gm2:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 24, 52)
  gm2:SetText("Importer GatherMate / GatherMate2")
  gm2:SetScript("OnClick", function() SlashCmdList["MITHRILGATHER"]("importgm2"); UpdateCount() end)
  tinsert(UISpecialFrames, "MithrilGatherFrame")
end

local function Toggle()
  if not frame then BuildUI() end
  UpdateCount()
  if frame:IsShown() then frame:Hide() else frame:Show() end
end

SLASH_MITHRILGATHER1 = "/mgather"
SlashCmdList["MITHRILGATHER"] = function(msg)
  EnsureDB()
  msg = string.lower(strtrim(msg or ""))
  if msg == "" then
    Toggle()
  elseif msg == "purge" then
    MithrilGatherDB.nodes = {}
    Print("Tous les points ont ete supprimes (les icones sont gardees).")
    RefreshWorld()
  elseif msg == "scangm" then
    for _, l in ipairs(G.ScanGM()) do Print(l) end
  elseif msg == "importgm2" or msg == "importgm" then
    local a, b, c, bad = G.ImportGM2()
    if not a then
      Print(b)
    else
      Print(a .. " point(s) importe(s) depuis GatherMate, " .. b .. " deja connu(s)" ..
        ((c and c > 0) and (", " .. c .. " zone(s) non reconnue(s) ignoree(s)") or "") ..
        ((bad and bad > 0) and (", " .. bad .. " point(s) invalide(s)") or "") .. ".")
      Print("Sur la minimap, les points importes apparaissent dans une zone apres t'y etre deplace un peu (calibrage).")
      RefreshWorld()
    end
  elseif msg == "debug" then
    local st = PlayerState()
    Print(st and ("Zone " .. st.key .. " continent " .. st.c .. " pos " .. string.format("%.4f %.4f", st.x, st.y) ..
      (st.cx and (" continent " .. string.format("%.5f %.5f", st.cx, st.cy)) or " (position continent indisponible)")) or "Position indisponible ici.")
    Print(NodeCount() .. " points. Sorts : " .. (next(spellType) and "reconnus" or "NON reconnus (GetSpellInfo)"))
    Print("Minimap zoom " .. tostring(Minimap:GetZoom()) .. ", rotation " .. tostring(GetCVar and GetCVar("rotateMinimap")))
  else
    Print("Commandes : /mgather | importgm | scangm | purge | debug")
  end
end
