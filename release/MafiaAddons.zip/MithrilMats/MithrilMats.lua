-- MithrilMats 0.1.0 - WoW 3.3.5 (Interface 30300)
-- Colle une liste de materiaux (un par ligne), l'add-on compare avec les sacs
-- (et la banque si tu l'as ouverte depuis la derniere connexion) et affiche le manque.
-- Formats acceptes par ligne :  "20 Barre de mithril"   "Barre de mithril x20"   "[Barre de mithril] 20"
-- Un lien d'objet (shift-clic) est accepte.
-- Groupe "au choix" (ex. des gemmes de couleurs differentes) :  "60 Pierre OT = 23077|21929|23112"
--   -> la quantite est comptee sur l'ensemble des objets listes apres le "=" (noms ou identifiants).

local TAG = "|cffd4a017MithrilMats|r "
local frame, input, output
local StartGuildScan   -- defini plus bas
local SortClick, SortStopClick, ResetSortPlan   -- rangement de l'onglet, definis plus bas
local sortBtn
local sortReady = false
MithrilMatsLoad = nil
local currentTabs = nil   -- onglets de banque de guilde pris en compte pour la liste en cours

-- Les variables sauvegardees sont chargees APRES ce fichier et peuvent venir d'une ancienne version :
-- on complete donc la base a chaque point d'entree.
MithrilMatsDB = MithrilMatsDB or {}
local function EnsureDB()
  MithrilMatsDB = MithrilMatsDB or {}
  MithrilMatsDB.guild = MithrilMatsDB.guild or {}   -- [onglet] = { t = heure du scan, items = { [idObjet] = quantite } }
  MithrilMatsDB.tabs = MithrilMatsDB.tabs or {}     -- onglets associes aux listes personnelles
  MithrilMatsDB.lists = MithrilMatsDB.lists or {}
end
EnsureDB()

local function Print(msg) DEFAULT_CHAT_FRAME:AddMessage(TAG .. tostring(msg)) end

local function Trim(s) return (string.gsub(s or "", "^%s*(.-)%s*$", "%1")) end

-- Renvoie nom, quantite, alternatives (ou nil)
local function ParseLine(line)
  line = Trim(line)
  if line == "" then return nil end
  local alts
  local left, right = string.match(line, "^(.-)%s*=%s*(.+)$")
  if left and right then
    line = left
    alts = {}
    for rawPart in string.gmatch(right .. "|", "([^|]*)|") do
      local part = Trim(rawPart)
      if part ~= "" then table.insert(alts, tonumber(part) or part) end
    end
    if #alts == 0 then alts = nil end
  end
  local linkName = string.match(line, "%[(.-)%]")
  local rest = line
  if linkName then
    rest = string.gsub(line, "|c%x%x%x%x%x%x%x%x|H.-|h%[.-%]|h|r", "#ITEM#")
    rest = string.gsub(rest, "|H.-|h%[.-%]|h", "#ITEM#")
    rest = string.gsub(rest, "%[.-%]", "#ITEM#")
  end
  local qty = string.match(rest, "^(%d+)%s*[xX]?%s") or string.match(rest, "[xX]%s*(%d+)%s*$") or string.match(rest, "%s(%d+)%s*$")
  local name = linkName
  if not name then
    name = rest
    name = string.gsub(name, "^%d+%s*[xX]?%s+", "")
    name = string.gsub(name, "%s+[xX]%s*%d+%s*$", "")
    name = string.gsub(name, "%s+%d+%s*$", "")
    name = Trim(name)
  end
  qty = tonumber(qty) or 1
  if name == "" then return nil end
  return name, qty, alts
end

local function ParseList(text)
  local items = {}
  for line in string.gmatch((text or "") .. "\n", "([^\r\n]*)[\r\n]") do
    local name, qty, alts = ParseLine(line)
    if name then
      local found
      for _, it in ipairs(items) do
        if string.lower(it.name) == string.lower(name) then it.qty = it.qty + qty; found = true; break end
      end
      if not found then table.insert(items, { name = name, qty = qty, alts = alts }) end
    end
  end
  return items
end

-- Identifiant d'un objet donne par id, nom ou lien (nil si inconnu)
local function ToItemId(ref)
  if type(ref) == "number" then return ref end
  local fromLink = string.match(tostring(ref), "item:(%d+)")
  if fromLink then return tonumber(fromLink) end
  if GetItemInfo then
    local _, link = GetItemInfo(ref)
    if link then return tonumber(string.match(link, "item:(%d+)")) end
  end
  return nil
end

-- Quantite d'un objet dans les onglets de banque de guilde (derniers scans)
local function GuildCount(ref, tabs)
  EnsureDB()
  if not tabs then return 0 end
  local id = ToItemId(ref)
  if not id then return 0 end
  local total = 0
  for _, tab in ipairs(tabs) do
    local rec = MithrilMatsDB.guild[tab]
    if rec and rec.items[id] then total = total + rec.items[id] end
  end
  return total
end

local function Compute(text, tabs)
  local items = ParseList(text)
  local lines, missingLines = {}, {}
  local totalMissing = 0
  for _, it in ipairs(items) do
    local have, guild = 0, 0
    local refs = it.alts or { it.name }
    for _, a in ipairs(refs) do
      have = have + (GetItemCount(a, true) or 0)
      guild = guild + GuildCount(a, tabs)
    end
    have = have + guild
    local miss = math.max(0, it.qty - have)
    local color = (miss == 0) and "|cff44ff44" or ((have > 0) and "|cffffcc33" or "|cffff5555")
    table.insert(lines, string.format("%s%s|r : %d / %d%s%s", color, it.name, have, it.qty,
      (guild > 0) and (" (dont guilde " .. guild .. ")") or "",
      (miss > 0) and ("   (manque " .. miss .. ")") or ""))
    if miss > 0 then
      totalMissing = totalMissing + 1
      table.insert(missingLines, miss .. " " .. it.name)
    end
  end
  return items, lines, missingLines, totalMissing
end

local function TabsText(tabs)
  local t = {}
  for _, n in ipairs(tabs) do table.insert(t, tostring(n)) end
  return table.concat(t, ", ")
end

-- Etat des scans de la banque de guilde pour les onglets demandes
local function GuildStatus(tabs)
  EnsureDB()
  if not tabs or #tabs == 0 then return "" end
  local never, oldest = {}, nil
  for _, tab in ipairs(tabs) do
    local rec = MithrilMatsDB.guild[tab]
    if not rec then
      table.insert(never, tab)
    elseif not oldest or rec.t < oldest then
      oldest = rec.t
    end
  end
  local txt = "|cff99ccffBanque de guilde, onglets " .. TabsText(tabs) .. "|r"
  if #never > 0 then
    txt = txt .. " : |cffff5555onglet(s) " .. TabsText(never) .. " jamais scanne(s), ouvre la banque de guilde|r"
  elseif oldest then
    local mins = math.floor((time() - oldest) / 60)
    txt = txt .. " : scan il y a " .. mins .. " min"
  end
  return txt .. "\n"
end

local tabBox, outScroll, outChild

local function DiagText()
  EnsureDB()
  local t = {}
  local function add(x) table.insert(t, x) end
  add("|cff99ccffDiagnostic banque de guilde|r")
  for _, fn in ipairs({ "GetNumGuildBankTabs", "QueryGuildBankTab", "SetCurrentGuildBankTab", "GetCurrentGuildBankTab",
    "GetGuildBankItemLink", "GetGuildBankItemInfo", "GetGuildBankTabInfo" }) do
    add((_G[fn] and "OK " or "|cffff5555ABSENT|r ") .. fn)
  end
  if GetNumGuildBankTabs then add("Onglets de la banque : " .. tostring(GetNumGuildBankTabs())) end
  if GetCurrentGuildBankTab then add("Onglet affiche : " .. tostring(GetCurrentGuildBankTab())) end
  local any
  for tab, rec in pairs(MithrilMatsDB.guild) do
    local n = 0
    for _ in pairs(rec.items) do n = n + 1 end
    add("Onglet " .. tab .. " : " .. n .. " objets, scan il y a " .. math.floor((time() - rec.t) / 60) .. " min")
    any = true
  end
  if not any then add("|cffff5555Aucun onglet scanne pour l'instant.|r") end
  add("Onglets demandes : " .. (currentTabs and TabsText(currentTabs) or "aucun"))
  return table.concat(t, "\n")
end

local function SetTabs(t)
  currentTabs = t
  if ResetSortPlan then ResetSortPlan() end
  if tabBox then tabBox:SetText(t and TabsText(t) or "") end
end

local function ReadTabs()
  if not tabBox then return currentTabs end
  local t = {}
  for n in string.gmatch(tabBox:GetText() or "", "%d+") do table.insert(t, tonumber(n)) end
  currentTabs = (#t > 0) and t or nil
  return currentTabs
end

local function Run()
  EnsureDB()
  if ResetSortPlan then ResetSortPlan() end
  ReadTabs()
  local items, lines, missingLines, total = Compute(input:GetText(), currentTabs)
  if #items == 0 then
    output:SetText("Aucune ligne valide. Ex : 20 Barre de mithril")
    return
  end
  local head = (total == 0) and "|cff44ff44Tout est la !|r\n" or ("|cffff5555" .. total .. " materiau(x) manquant(s)|r\n")
  output:SetText(GuildStatus(currentTabs) .. head .. table.concat(lines, "\n"))
  MithrilMatsDB.lastMissing = table.concat(missingLines, "\n")
  if outChild then
    outChild:SetHeight(math.max(10, (output:GetStringHeight() or 0) + 10))
    if outScroll and outScroll.SetVerticalScroll then outScroll:SetVerticalScroll(0) end
  end
end

local function BuildUI()
  frame = CreateFrame("Frame", "MithrilMatsFrame", UIParent)
  frame:SetWidth(520)
  frame:SetHeight(600)
  frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  frame:SetFrameStrata("DIALOG")
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
  frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
  })
  frame:Hide()

  local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOP", frame, "TOP", 0, -18)
  title:SetText("Materiaux de kit")
  local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -6, -6)

  local help = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
  help:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -42)
  help:SetWidth(476)
  help:SetJustifyH("LEFT")
  help:SetText("Colle la liste (un objet par ligne) ou /mmats load inge-1, puis Calculer. Ou clique sur un kit : liste et onglet de guilde se chargent.")

  local scroll = CreateFrame("ScrollFrame", "MithrilMatsScroll", frame, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -62)
  scroll:SetWidth(450)
  scroll:SetHeight(130)
  input = CreateFrame("EditBox", "MithrilMatsInput", scroll)
  input:SetMultiLine(true)
  input:SetAutoFocus(false)
  input:SetFontObject(ChatFontNormal)
  input:SetWidth(440)
  input:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  scroll:SetScrollChild(input)

  local calc = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  calc:SetWidth(100); calc:SetHeight(24)
  calc:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -200)
  calc:SetText("Calculer")
  calc:SetScript("OnClick", Run)

  local clear = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  clear:SetWidth(100); clear:SetHeight(24)
  clear:SetPoint("LEFT", calc, "RIGHT", 8, 0)
  clear:SetText("Vider")
  clear:SetScript("OnClick", function() input:SetText(""); output:SetText(""); SetTabs(nil) end)

  local miss = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  miss:SetWidth(160); miss:SetHeight(24)
  miss:SetPoint("LEFT", clear, "RIGHT", 8, 0)
  miss:SetText("Garder le manque")
  miss:SetScript("OnClick", function()
    Run()
    if MithrilMatsDB.lastMissing and MithrilMatsDB.lastMissing ~= "" then
      input:SetText(MithrilMatsDB.lastMissing)
      Run()
    end
  end)

  -- Boutons de kit : chargent la liste et l'onglet de banque de guilde correspondant
  local KITS = { { "Inge 1", "inge-1" }, { "Inge 2", "inge-2" }, { "Joa 1", "joa-1" }, { "Joa 2", "joa-2" } }
  local prev
  for _, k in ipairs(KITS) do
    local kb = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    kb:SetWidth(62); kb:SetHeight(22)
    if prev then kb:SetPoint("LEFT", prev, "RIGHT", 2, 0) else kb:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -230) end
    kb:SetText(k[1])
    kb:SetScript("OnClick", function() MithrilMatsLoad(k[2]) end)
    prev = kb
  end

  local scanBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  scanBtn:SetWidth(72); scanBtn:SetHeight(22)
  scanBtn:SetPoint("LEFT", prev, "RIGHT", 10, 0)
  scanBtn:SetText("Scanner")
  scanBtn:SetScript("OnClick", function()
    if not (GetNumGuildBankTabs and GuildBankFrame and GuildBankFrame:IsVisible()) then
      output:SetText("|cffff5555Ouvre d'abord la banque de guilde, puis clique sur Scanner.|r")
      return
    end
    ReadTabs()
    StartGuildScan()
    output:SetText("Scan lance... patiente 2-3 secondes puis clique sur Calculer.")
  end)
  local diagBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  diagBtn:SetWidth(84); diagBtn:SetHeight(22)
  diagBtn:SetPoint("LEFT", scanBtn, "RIGHT", 4, 0)
  diagBtn:SetText("Diagnostic")
  diagBtn:SetScript("OnClick", function()
    local ok, res = pcall(function() ReadTabs(); return DiagText() end)
    local txt = ok and res or ("|cffff5555Erreur diagnostic : " .. tostring(res) .. "|r")
    output:SetText(txt)
    outChild:SetHeight(math.max(10, (output:GetStringHeight() or 0) + 10))
    if outScroll and outScroll.SetVerticalScroll then outScroll:SetVerticalScroll(0) end
    Print(ok and "Diagnostic affiche dans la fenetre." or txt)
  end)

  outScroll = CreateFrame("ScrollFrame", "MithrilMatsOutScroll", frame, "UIPanelScrollFrameTemplate")
  outScroll:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -262)
  outScroll:SetWidth(450)
  outScroll:SetHeight(282)
  sortBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  sortBtn:SetWidth(230); sortBtn:SetHeight(24)
  sortBtn:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -552)
  sortBtn:SetText("Ranger l'onglet (apercu)")
  sortBtn:SetScript("OnClick", function() SortClick() end)
  local stopBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  stopBtn:SetWidth(100); stopBtn:SetHeight(24)
  stopBtn:SetPoint("LEFT", sortBtn, "RIGHT", 8, 0)
  stopBtn:SetText("Arreter")
  stopBtn:SetScript("OnClick", function() SortStopClick() end)

  outChild = CreateFrame("Frame", nil, outScroll)
  outChild:SetWidth(440)
  outChild:SetHeight(10)
  outScroll:SetScrollChild(outChild)
  output = outChild:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
  output:SetPoint("TOPLEFT", outChild, "TOPLEFT", 2, 0)
  output:SetWidth(436)
  output:SetJustifyH("LEFT")
  output:SetJustifyV("TOP")

  tinsert(UISpecialFrames, "MithrilMatsFrame")
end

local function Toggle()
  if not frame then BuildUI() end
  if frame:IsShown() then frame:Hide() else frame:Show() end
end

MithrilMatsLoad = function(name)
  EnsureDB()
  MithrilMatsDB.lists = MithrilMatsDB.lists or {}
  local presets = _G.MithrilMatsPresets or {}
  local text = MithrilMatsDB.lists[name] or presets[name]
  if not text then Print("Liste inconnue : " .. name .. " (/mmats list pour voir les listes)"); return end
  if not frame then BuildUI() end
  input:SetText(text)
  SetTabs(MithrilMatsDB.tabs[name] or (_G.MithrilMatsTabs or {})[name])
  frame:Show()
  Run()
end

local function Command(msg)
  EnsureDB()
  local cmd, name = strsplit(" ", strtrim(msg or ""), 2)
  cmd = string.lower(cmd or "")
  MithrilMatsDB.lists = MithrilMatsDB.lists or {}
  if cmd == "" then
    Toggle()
  elseif cmd == "save" and name and name ~= "" then
    if not frame then BuildUI() end
    MithrilMatsDB.lists[name] = input:GetText()
    MithrilMatsDB.tabs[name] = ReadTabs()
    Print("Liste \"" .. name .. "\" enregistree.")
  elseif cmd == "load" and name and name ~= "" then
    MithrilMatsLoad(name)
  elseif cmd == "list" then
    local any
    for n in pairs(_G.MithrilMatsPresets or {}) do Print("- " .. n .. " (liste fournie)"); any = true end
    for n in pairs(MithrilMatsDB.lists) do Print("- " .. n); any = true end
    if not any then Print("Aucune liste enregistree.") end
  elseif cmd == "tabs" then
    if name and string.lower(name) == "off" then
      SetTabs(nil)
      Print("Banque de guilde ignoree pour la liste en cours.")
    elseif name and name ~= "" then
      local t = {}
      for n in string.gmatch(name, "%d+") do table.insert(t, tonumber(n)) end
      SetTabs((#t > 0) and t or nil)
      Print(currentTabs and ("Onglets de guilde : " .. TabsText(currentTabs)) or "Aucun onglet valide.")
    else
      Print(currentTabs and ("Onglets de guilde : " .. TabsText(currentTabs)) or "Aucun onglet de guilde pour la liste en cours.")
    end
  elseif cmd == "debug" then
    for tab, rec in pairs(MithrilMatsDB.guild) do
      local n = 0
      for _ in pairs(rec.items) do n = n + 1 end
      Print("Onglet " .. tab .. " : " .. n .. " objets, scan il y a " .. math.floor((time() - rec.t) / 60) .. " min")
    end
    for _, fn in ipairs({ "GetNumGuildBankTabs", "QueryGuildBankTab", "SetCurrentGuildBankTab", "GetCurrentGuildBankTab",
      "GetGuildBankItemLink", "GetGuildBankItemInfo", "GetGuildBankTabInfo" }) do
      Print((_G[fn] and "OK " or "ABSENT ") .. fn)
    end
  elseif cmd == "delete" and name then
    MithrilMatsDB.lists[name] = nil
    Print("Liste supprimee : " .. name)
  else
    Print("Commandes : /mmats | save <nom> | load <nom> | list | delete <nom> | tabs <n n...|off> | debug")
  end
end

SLASH_MITHRILMATS1 = "/mmats"
SlashCmdList["MITHRILMATS"] = Command

-- ------------------------------------------------------------------ banque de guilde
local SLOTS_PER_TAB = 98
local queue, queueTab, queueSince, origTab = nil, nil, 0, nil

local function ScanTab(tab)
  EnsureDB()
  local items = {}
  for slot = 1, SLOTS_PER_TAB do
    local link = GetGuildBankItemLink and GetGuildBankItemLink(tab, slot)
    if link then
      local id = tonumber(string.match(link, "item:(%d+)"))
      if id then
        local _, count = GetGuildBankItemInfo(tab, slot)
        items[id] = (items[id] or 0) + (count or 1)
      end
    end
  end
  MithrilMatsDB.guild[tab] = { t = time(), items = items }
end

-- Onglets utiles : ceux des listes fournies, des listes personnelles et de la liste en cours
local function WantedTabs()
  EnsureDB()
  local set, list = {}, {}
  local function add(tabs)
    for _, n in ipairs(tabs or {}) do
      if not set[n] then set[n] = true; table.insert(list, n) end
    end
  end
  for _, t in pairs(_G.MithrilMatsTabs or {}) do add(t) end
  for _, t in pairs(MithrilMatsDB.tabs or {}) do add(t) end
  add(currentTabs)
  table.sort(list)
  return list
end

local function NextInQueue()
  queueTab = table.remove(queue, 1)
  if queueTab then
    queueSince = GetTime()
    if SetCurrentGuildBankTab then SetCurrentGuildBankTab(queueTab) end
    QueryGuildBankTab(queueTab)
  else
    queue = nil
    if origTab and SetCurrentGuildBankTab then
      SetCurrentGuildBankTab(origTab)
      QueryGuildBankTab(origTab)
    end
    Print("Banque de guilde scannee. /mmats pour recalculer.")
  end
end

StartGuildScan = function()
  if not (GetNumGuildBankTabs and QueryGuildBankTab) then return end
  local num = GetNumGuildBankTabs() or 0
  queue = {}
  for _, tab in ipairs(WantedTabs()) do
    local viewable = true
    if GetGuildBankTabInfo then
      local _, _, v = GetGuildBankTabInfo(tab)
      viewable = (v ~= nil and v) or (v == nil)
    end
    if tab <= num and viewable then table.insert(queue, tab) end
  end
  if #queue == 0 then queue = nil; return end
  origTab = GetCurrentGuildBankTab and GetCurrentGuildBankTab() or nil
  NextInQueue()
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("GUILDBANKFRAME_OPENED")
ev:RegisterEvent("GUILDBANKFRAME_CLOSED")
ev:RegisterEvent("GUILDBANKBAGSLOTS_CHANGED")
ev:SetScript("OnEvent", function(self, event)
  if event == "PLAYER_LOGIN" then
    EnsureDB()
    Print("charge. /mmats pour comparer une liste de materiaux avec tes sacs.")
  elseif event == "GUILDBANKFRAME_OPENED" then
    StartGuildScan()
  elseif event == "GUILDBANKFRAME_CLOSED" then
    queue = nil
  elseif event == "GUILDBANKBAGSLOTS_CHANGED" then
    sortReady = true
    local tab = GetCurrentGuildBankTab and GetCurrentGuildBankTab()
    if queue and queueTab then
      ScanTab(queueTab)
      NextInQueue()
    elseif tab then
      ScanTab(tab)   -- onglet consulte a la main : on garde aussi ses donnees
    end
  end
end)
-- Securite : si un onglet ne repond pas, on passe au suivant
ev:SetScript("OnUpdate", function()
  if queue and queueTab and GetTime() - queueSince > 3 then NextInQueue() end
end)

-- ------------------------------------------------------------------ rangement de l'onglet
-- Range les piles de l'onglet affiche dans l'ordre de la liste du kit, colonne par colonne
-- (les cases de la banque de guilde sont numerotees de haut en bas, colonne apres colonne).
-- Uniquement des echanges de places : aucune pile n'est fusionnee ni coupee.
local SORT_SLOTS = 98
local sortPlan, S = nil, nil

local function SetSortLabel(txt) if sortBtn then sortBtn:SetText(txt) end end
local function ShowOut(txt)
  if output then
    output:SetText(txt)
    if outChild then outChild:SetHeight(math.max(10, (output:GetStringHeight() or 0) + 10)) end
  end
end

ResetSortPlan = function()
  if S then return end            -- pas de reinitialisation pendant un rangement
  sortPlan = nil
  SetSortLabel("Ranger l'onglet (apercu)")
end

local function ReadStacks(tab)
  local cur = {}
  for slot = 1, SORT_SLOTS do
    local link = GetGuildBankItemLink and GetGuildBankItemLink(tab, slot)
    if link then
      local id = tonumber(string.match(link, "item:(%d+)"))
      local _, count = GetGuildBankItemInfo(tab, slot)
      if id then cur[slot] = { id = id, count = count or 1 } end
    end
  end
  return cur
end

-- Taille maximale d'une pile (GetItemInfo si l'objet est connu, sinon 20, ou plus si on en voit de plus grosses)
local function StackSizeFor(id, observedMax)
  if GetItemInfo then
    local sc = select(8, GetItemInfo(id))
    if type(sc) == "number" and sc > 0 then return sc end
  end
  return math.max(20, observedMax[id] or 0)
end

-- Calcule la disposition cible et la liste des deplacements.
-- Disposition = celle du kit COMPLET : chaque ligne de la liste reserve le nombre de cases dont elle a besoin
-- (quantite / taille de pile), dans l'ordre, colonne par colonne. Les cases d'un objet que tu n'as pas
-- encore restent vides. Ce qui n'est pas dans la liste (ou depasse la quantite) va apres le kit.
local function BuildSortPlan(tab, text)
  local cur = ReadStacks(tab)
  local observedMax = {}
  for _, st in pairs(cur) do if st.count > (observedMax[st.id] or 0) then observedMax[st.id] = st.count end end

  local entries = ParseList(text)
  local entryOf, idOrder, reserve = {}, {}, {}
  local nextSlot = 1
  for i, it in ipairs(entries) do
    local first
    for k, ref in ipairs(it.alts or { it.name }) do
      local id = ToItemId(ref)
      if id and not entryOf[id] then entryOf[id] = i; idOrder[id] = k end
      if id and not first then first = id end
    end
    local ss = first and StackSizeFor(first, observedMax) or 20
    local n = math.max(1, math.ceil(it.qty / ss))
    reserve[i] = { base = nextSlot, n = n }
    nextSlot = nextSlot + n
  end
  local reservedTotal = nextSlot - 1

  local stacks = {}
  for slot = 1, SORT_SLOTS do
    local st = cur[slot]
    if st then table.insert(stacks, { tag = slot, id = st.id, count = st.count, entry = entryOf[st.id] }) end
  end

  -- regroupe les piles par ligne de la liste
  local byEntry, others = {}, {}
  for _, st in ipairs(stacks) do
    if st.entry then
      byEntry[st.entry] = byEntry[st.entry] or {}
      table.insert(byEntry[st.entry], st)
    else
      table.insert(others, st)
    end
  end
  local function sortStacks(list)
    table.sort(list, function(a, b)
      local oa, ob = idOrder[a.id] or 0, idOrder[b.id] or 0
      if oa ~= ob then return oa < ob end
      if a.id ~= b.id then return a.id < b.id end
      if a.count ~= b.count then return a.count > b.count end
      return a.tag < b.tag
    end)
  end

  -- cases cibles : on place d'abord dans la reservation de la ligne, le reste en surplus
  local target, overflow, packed = {}, {}, false
  for i = 1, #entries do
    local list = byEntry[i]
    if list then
      sortStacks(list)
      for k, st in ipairs(list) do
        if k <= reserve[i].n then target[st.tag] = reserve[i].base + k - 1 else table.insert(overflow, st) end
      end
    end
  end
  sortStacks(others)
  for _, st in ipairs(others) do table.insert(overflow, st) end
  if reservedTotal + #overflow > SORT_SLOTS then
    -- le kit complet + le surplus ne tient pas dans l'onglet : rangement compact, sans cases reservees
    packed = true
    target = {}
    local all = {}
    for i = 1, #entries do for _, st in ipairs(byEntry[i] or {}) do table.insert(all, st) end end
    for _, st in ipairs(others) do table.insert(all, st) end
    for k, st in ipairs(all) do target[st.tag] = k end
  else
    for k, st in ipairs(overflow) do target[st.tag] = reservedTotal + k end
  end

  -- simulation : on traite les piles par case cible croissante ; si la case est prise, on echange
  local arr, posOf = {}, {}
  for slot, st in pairs(cur) do arr[slot] = { tag = slot, id = st.id, count = st.count }; posOf[slot] = slot end
  local order = {}
  for _, st in ipairs(stacks) do table.insert(order, st) end
  table.sort(order, function(a, b) return target[a.tag] < target[b.tag] end)
  local moves = {}
  for _, st in ipairs(order) do
    local t, pos = target[st.tag], posOf[st.tag]
    if pos ~= t then
      local there = arr[t]
      table.insert(moves, { from = pos, to = t, id = st.id, count = st.count,
        displaced = there and { id = there.id, count = there.count } or nil })
      arr[t], arr[pos] = arr[pos], there
      posOf[st.tag] = t
      if there then posOf[there.tag] = pos end
    end
  end
  local placed = 0
  for _ in pairs(target) do placed = placed + 1 end
  return { tab = tab, moves = moves, stacks = #stacks, reserved = packed and 0 or reservedTotal,
    empty = packed and 0 or math.max(0, reservedTotal - (#stacks - #overflow)), packed = packed }
end

local function Describe(plan)
  local lines = { "|cff99ccffRangement de l'onglet " .. plan.tab .. "|r",
    plan.stacks .. " pile(s), " .. #plan.moves .. " deplacement(s) prevu(s)." }
  if plan.packed then
    table.insert(lines, "|cffffcc33Kit complet + surplus > 98 cases : rangement compact, sans cases reservees.|r")
  else
    table.insert(lines, "Disposition du kit complet : " .. plan.reserved .. " cases reservees, dont environ " .. plan.empty .. " restent vides (ce qu'il te manque).")
  end
  if #plan.moves == 0 then
    table.insert(lines, "|cff44ff44L'onglet est deja dans l'ordre de la liste.|r")
  else
    table.insert(lines, "Clique sur |cffffcc33Confirmer|r pour lancer. Ne touche pas a la banque pendant le rangement. |cffff5555Arreter|r interrompt.")
  end
  return table.concat(lines, "\n")
end

local function SortFinish(msg, ok)
  if ClearCursor then ClearCursor() end
  S = nil
  sortPlan = nil
  SetSortLabel("Ranger l'onglet (apercu)")
  Print(msg)
  ShowOut((ok and "|cff44ff44" or "|cffff5555") .. msg .. "|r")
end

SortStopClick = function()
  if S then SortFinish("Rangement interrompu.", false) end
end

SortClick = function()
  if S then return end
  if not (GuildBankFrame and GuildBankFrame:IsVisible() and GetCurrentGuildBankTab) then
    ShowOut("|cffff5555Ouvre la banque de guilde et affiche l'onglet du kit.|r"); return
  end
  ReadTabs()
  if not currentTabs or #currentTabs ~= 1 then
    ShowOut("|cffff5555Choisis d'abord un kit (Inge 1, Inge 2, Joa 1, Joa 2).|r"); return
  end
  local tab = currentTabs[1]
  if GetCurrentGuildBankTab() ~= tab then
    ShowOut("|cffff5555Affiche l'onglet " .. tab .. " de la banque de guilde, puis reclique.|r"); return
  end
  if not sortPlan or sortPlan.tab ~= tab then
    sortPlan = BuildSortPlan(tab, input:GetText())
    ShowOut(Describe(sortPlan))
    if #sortPlan.moves > 0 then SetSortLabel("Confirmer le rangement (" .. #sortPlan.moves .. ")") else sortPlan = nil end
    return
  end
  -- confirmation : on lance
  local plan = sortPlan
  S = { plan = plan, mi = 0, clicks = {}, ci = 1, t = 0, phase = "start", attempts = 0 }
  SetSortLabel("Rangement en cours...")
  Print("Rangement lance : " .. #plan.moves .. " deplacement(s).")
end

local function ReadSlot(tab, slot)
  local link = GetGuildBankItemLink(tab, slot)
  if not link then return nil, 0, false end
  local id = tonumber(string.match(link, "item:(%d+)"))
  local _, count, locked = GetGuildBankItemInfo(tab, slot)
  return id, count or 1, locked and true or false
end

local function SlotText(tab, slot)
  local id, c = ReadSlot(tab, slot)
  return id and (id .. "x" .. c) or "vide"
end

-- Machine a etats : un clic a la fois, on attend que le serveur ait traite chaque clic
-- (curseur dans l'etat attendu), puis on relit la banque avant de verifier le deplacement.
--   click -> settle -> (clic suivant ... ) -> verify -> verifywait -> deplacement suivant
local function NextMove()
  local plan = S.plan
  S.mi = S.mi + 1
  local mv = plan.moves[S.mi]
  if not mv then SortFinish("Rangement termine : " .. #plan.moves .. " deplacement(s).", true); return end
  S.mv = mv
  S.clicks = { mv.from, mv.to }
  S.expectCursor = { true, mv.displaced and true or false }
  if mv.displaced then S.clicks[3] = mv.from; S.expectCursor[3] = false end
  S.ci = 1
  S.attempts = 0
  S.phase = "click"
  S.t = 0
  ShowOut("Rangement : " .. S.mi .. " / " .. #plan.moves)
end

local sorter = CreateFrame("Frame")
sorter:SetScript("OnUpdate", function(self, dt)
  if not S then return end
  S.t = S.t + (dt or 0)
  if S.t < 0.3 then return end
  if not (GuildBankFrame and GuildBankFrame:IsVisible()) then SortFinish("Banque fermee : rangement interrompu.", false); return end
  local plan = S.plan
  if GetCurrentGuildBankTab() ~= plan.tab then SortFinish("Onglet change : rangement interrompu.", false); return end

  if S.phase == "start" then
    NextMove()
  elseif S.phase == "click" then
    local mv = S.mv
    local slot = S.clicks[S.ci]
    if S.ci == 1 then
      -- avant de toucher a quoi que ce soit : la case source doit contenir la pile prevue
      local id, count = ReadSlot(plan.tab, mv.from)
      if id ~= mv.id or count ~= mv.count then
        SortFinish("L'onglet ne correspond plus a l'apercu (case " .. mv.from .. " = " .. SlotText(plan.tab, mv.from) ..
          ", attendu " .. mv.id .. "x" .. mv.count .. ") : rien n'a ete deplace pour ce pas, relance l'apercu.", false)
        return
      end
    end
    local _, _, locked = ReadSlot(plan.tab, slot)
    if locked and S.t < 4 then return end              -- case encore verrouillee par le serveur
    sortReady = false
    PickupGuildBankItem(plan.tab, slot)
    S.phase = "settle"
    S.t = 0
  elseif S.phase == "settle" then
    -- On attend la reponse du serveur (evenement) ou 1,5 s avant le clic suivant : aller plus vite
    -- fait ignorer des clics par le serveur. La verification relit ensuite le contenu des cases.
    if sortReady or S.t >= 1.5 then
      S.ci = S.ci + 1
      S.t = 0
      if S.ci > #S.clicks then S.phase = "verify" else S.phase = "click" end
    end
  elseif S.phase == "verify" then
    if QueryGuildBankTab then QueryGuildBankTab(plan.tab) end
    sortReady = false
    S.phase = "verifywait"
    S.t = 0
  elseif S.phase == "verifywait" then
    if not sortReady and S.t < 2.5 then return end
    local mv = S.mv
    local id, count = ReadSlot(plan.tab, mv.to)
    local ok = (id == mv.id and count == mv.count)
    if ok and mv.displaced then
      local id2, c2 = ReadSlot(plan.tab, mv.from)
      ok = (id2 == mv.displaced.id and c2 == mv.displaced.count)
    end
    if CursorHasItem and CursorHasItem() then ok = false end
    if ok then
      NextMove()
    else
      S.attempts = S.attempts + 1
      if S.attempts < 4 then
        S.phase = "verify"; S.t = 0                    -- le serveur peut etre en retard : on relit
      else
        SortFinish("Echec de verification au deplacement " .. S.mi .. " : case " .. mv.to .. " = " .. SlotText(plan.tab, mv.to) ..
          " (attendu " .. mv.id .. "x" .. mv.count .. "), case " .. mv.from .. " = " .. SlotText(plan.tab, mv.from) ..
          ". Curseur : " .. ((CursorHasItem and CursorHasItem()) and "plein" or "vide") ..
          ((GetCursorInfo and GetCursorInfo()) and (" (GetCursorInfo : " .. tostring(GetCursorInfo()) .. ")") or "") ..
          ". Rangement arrete.", false)
      end
    end
  end
end)

_G.MithrilMats = { BuildSortPlan = BuildSortPlan, ParseLine = ParseLine, ParseList = ParseList, Compute = Compute, ScanTab = ScanTab, StartGuildScan = StartGuildScan }
