-- MithrilHub : bouton de minimap qui regroupe les add-ons Mafia du Mithril.
-- Clic = menu. Glisser = deplacer le bouton autour de la minimap.
-- /mhub : afficher/masquer le bouton (/mhub reset pour le remettre en place).

local TAG = "|cffd4a017MithrilHub|r "
local ICON = "Interface\\Icons\\INV_Ore_Mithril_02"
local RADIUS = 80

-- Version du pack d'add-ons (a garder identique a "version" dans version.json,
-- l'outil MettreAJour.exe compare avec ce numero). Mise a jour par
-- make-release.py : ne pas modifier a la main.
local PACK_VERSION = "1.0.7"
local VER_PREFIX = "MAFIAVER"

local ENTRIES = {
  { label = "Courriers (vente)",    slash = "MITHRILMAIL",   addon = "MithrilMail" },
  { label = "Carnet de ventes",     slash = "MITHRILLEDGER", addon = "MithrilLedger" },
  { label = "Materiaux de kit",     slash = "MITHRILMATS",   addon = "MithrilMats" },
  { label = "Annonces",             slash = "MITHRILADS",    addon = "MithrilAds" },
  { label = "Recoltes (carte)",      slash = "MITHRILGATHER", addon = "MithrilGather" },
}

MithrilHubDB = MithrilHubDB or {}
local button, menu, badge

local function Print(msg) DEFAULT_CHAT_FRAME:AddMessage(TAG .. tostring(msg)) end

local function EnsureDB()
  MithrilHubDB = MithrilHubDB or {}
  if type(MithrilHubDB.angle) ~= "number" then MithrilHubDB.angle = 215 end
  if MithrilHubDB.hidden == nil then MithrilHubDB.hidden = false end
  if type(MithrilHubDB.latest) ~= "string" then MithrilHubDB.latest = "" end
end

-- ---------------------------------------------------------- versions
-- "1.2.10" -> {1,2,10} ; renvoie true si a est strictement plus recent que b
local function VersionNewer(a, b)
  local function parts(v)
    local t = {}
    for n in string.gmatch(tostring(v or ""), "%d+") do t[#t + 1] = tonumber(n) end
    return t
  end
  local pa, pb = parts(a), parts(b)
  for i = 1, math.max(#pa, #pb) do
    local x, y = pa[i] or 0, pb[i] or 0
    if x ~= y then return x > y end
  end
  return false
end

local function IsOutdated()
  return MithrilHubDB and MithrilHubDB.latest ~= "" and VersionNewer(MithrilHubDB.latest, PACK_VERSION)
end

local function RefreshBadge()
  if badge then
    if IsOutdated() then badge:Show() else badge:Hide() end
  end
end

local announced = false
local function NoteVersion(v)
  if type(v) ~= "string" or v == "" then return end
  if VersionNewer(v, MithrilHubDB.latest) then MithrilHubDB.latest = v end
  RefreshBadge()
  if IsOutdated() and not announced then
    announced = true
    Print("|cffff4040Nouvelle version des add-ons disponible : " .. MithrilHubDB.latest ..
      "|r (tu as la " .. PACK_VERSION .. "). Ferme le jeu, lance |cffffff00MettreAJour.exe|r puis relance WoW.")
  end
end

-- Diffusion de la version, comme DBM : guilde, groupe / raid / champ de bataille, et chuchotement aux amis connectes.
-- (un add-on ne peut pas ecrire a un inconnu : ces voies sont les seules qui touchent des joueurs hors guilde)
local replied = {}
local function Send(channel, target)
  if not SendAddonMessage then return end
  if channel == "WHISPER" then
    if target and target ~= "" then SendAddonMessage(VER_PREFIX, "V:" .. PACK_VERSION, "WHISPER", target) end
  elseif channel then
    SendAddonMessage(VER_PREFIX, "V:" .. PACK_VERSION, channel)
  end
end

local function GroupChannel()
  if UnitInBattleground and UnitInBattleground("player") then return "BATTLEGROUND" end
  if GetNumRaidMembers and GetNumRaidMembers() > 0 then return "RAID" end
  if GetNumPartyMembers and GetNumPartyMembers() > 0 then return "PARTY" end
  return nil
end

local function Broadcast()
  if IsInGuild and IsInGuild() then Send("GUILD") end
  Send(GroupChannel())
end

local whispered = {}      -- ami -> heure du dernier envoi
local function WhisperFriends()
  if not GetNumFriends or not GetFriendInfo then return end
  local me, now = UnitName("player"), GetTime()
  for i = 1, GetNumFriends() do
    local name, _, _, _, connected = GetFriendInfo(i)
    if name and connected and name ~= me and (not whispered[name] or now - whispered[name] > 600) then
      whispered[name] = now
      Send("WHISPER", name)
    end
  end
end

local function UpdatePosition()
  local a = math.rad(MithrilHubDB.angle or 215)
  button:ClearAllPoints()
  button:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * RADIUS, math.sin(a) * RADIUS)
end

local function OpenEntry(e)
  local fn = SlashCmdList and SlashCmdList[e.slash]
  if fn then
    fn("")
  else
    Print(e.addon .. " n'est pas installe ou pas active.")
  end
end

local function BuildMenu()
  menu = CreateFrame("Frame", "MithrilHubMenu", UIParent)
  menu:SetFrameStrata("DIALOG")
  menu:SetWidth(190)
  menu:SetHeight(52 + #ENTRIES * 26)
  menu:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 24,
    insets = { left = 6, right = 6, top = 6, bottom = 6 },
  })
  menu:Hide()
  local title = menu:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  title:SetPoint("TOP", menu, "TOP", 0, -10)
  title:SetText("Mafia du Mithril")
  local upd = menu:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
  upd:SetPoint("BOTTOM", menu, "BOTTOM", 0, 10)
  upd:SetTextColor(1, 0.25, 0.25)
  menu.upd = upd
  menu:SetScript("OnShow", function(self)
    if IsOutdated() then
      self.upd:SetText("Mise a jour " .. MithrilHubDB.latest .. " dispo !")
    else
      self.upd:SetText("")
    end
  end)
  for i, e in ipairs(ENTRIES) do
    local b = CreateFrame("Button", nil, menu, "UIPanelButtonTemplate")
    b:SetWidth(166); b:SetHeight(22)
    b:SetPoint("TOP", menu, "TOP", 0, -26 - (i - 1) * 26)
    b:SetText(e.label)
    b:SetScript("OnClick", function() menu:Hide(); OpenEntry(e) end)
  end
  tinsert(UISpecialFrames, "MithrilHubMenu")
end

local function ToggleMenu()
  if not menu then BuildMenu() end
  if menu:IsShown() then
    menu:Hide()
  else
    menu:ClearAllPoints()
    -- le menu s'ouvre du cote de l'ecran ou il y a de la place
    local x, y = button:GetCenter()
    local w, h = UIParent:GetWidth(), UIParent:GetHeight()
    local horiz = (x and x > w / 2) and "RIGHT" or "LEFT"
    local vert = (y and y > h / 2) and "TOP" or "BOTTOM"
    local selfPt = ((vert == "TOP") and "TOP" or "BOTTOM") .. horiz
    local relPt = ((vert == "TOP") and "BOTTOM" or "TOP") .. horiz
    menu:SetPoint(selfPt, button, relPt, 0, (vert == "TOP") and -4 or 4)
    menu:Show()
  end
end

local function BuildButton()
  button = CreateFrame("Button", "MithrilHubButton", Minimap)
  button:SetWidth(31); button:SetHeight(31)
  button:SetFrameStrata("MEDIUM")
  button:SetFrameLevel(8)
  button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
  button:RegisterForDrag("LeftButton")
  button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

  local icon = button:CreateTexture(nil, "BACKGROUND")
  icon:SetTexture(ICON)
  icon:SetWidth(20); icon:SetHeight(20)
  icon:SetPoint("CENTER", button, "CENTER", 0, 1)
  icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
  local border = button:CreateTexture(nil, "OVERLAY")
  border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
  border:SetWidth(53); border:SetHeight(53)
  border:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)

  badge = button:CreateTexture(nil, "OVERLAY")
  badge:SetTexture("Interface\\Minimap\\ObjectIcons")
  badge:SetTexCoord(0.5, 0.75, 0.0, 0.25)   -- point d'exclamation (alerte)
  badge:SetWidth(14); badge:SetHeight(14)
  badge:SetPoint("TOPRIGHT", button, "TOPRIGHT", 2, 2)
  badge:Hide()
  RefreshBadge()

  button:SetScript("OnClick", function() ToggleMenu() end)
  button:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
      local mx, my = Minimap:GetCenter()
      local px, py = GetCursorPosition()
      local scale = Minimap:GetEffectiveScale()
      px, py = px / scale, py / scale
      MithrilHubDB.angle = math.deg(math.atan2(py - my, px - mx))
      UpdatePosition()
    end)
  end)
  button:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
  button:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("Mafia du Mithril")
    GameTooltip:AddLine("Clic : ouvrir le menu", 1, 1, 1)
    GameTooltip:AddLine("Glisser : deplacer le bouton", 1, 1, 1)
    GameTooltip:AddLine("Version du pack : " .. PACK_VERSION, 0.7, 0.7, 0.7)
    if IsOutdated() then
      GameTooltip:AddLine("Mise a jour " .. MithrilHubDB.latest .. " disponible : lance MettreAJour.exe", 1, 0.3, 0.3)
    end
    GameTooltip:Show()
  end)
  button:SetScript("OnLeave", function() GameTooltip:Hide() end)
  UpdatePosition()
  if MithrilHubDB.hidden then button:Hide() else button:Show() end
end

SLASH_MITHRILHUB1 = "/mhub"
SlashCmdList["MITHRILHUB"] = function(msg)
  EnsureDB()
  msg = string.lower(strtrim(msg or ""))
  if not button then BuildButton() end
  if msg == "reset" then
    MithrilHubDB.angle = 215; MithrilHubDB.hidden = false
    UpdatePosition(); button:Show()
    Print("Bouton remis a sa place.")
  elseif button:IsShown() then
    MithrilHubDB.hidden = true; button:Hide()
    Print("Bouton masque. /mhub pour le reafficher.")
  else
    MithrilHubDB.hidden = false; button:Show()
    Print("Bouton affiche.")
  end
end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("CHAT_MSG_ADDON")
ev:RegisterEvent("PLAYER_GUILD_UPDATE")
ev:RegisterEvent("PARTY_MEMBERS_CHANGED")
ev:RegisterEvent("RAID_ROSTER_UPDATE")
ev:RegisterEvent("FRIENDLIST_UPDATE")
local sendAt, sent = nil, false
local groupAt, lastGroup = nil, -1000
ev:SetScript("OnEvent", function(self, event, prefix, message, channel, sender)
  if event == "PLAYER_LOGIN" then
    EnsureDB()
    if RegisterAddonMessagePrefix then RegisterAddonMessagePrefix(VER_PREFIX) end
    if not button then BuildButton() end
    sendAt = GetTime() + 20          -- laisse la guilde se charger
    if IsOutdated() then NoteVersion(MithrilHubDB.latest) end
  elseif event == "CHAT_MSG_ADDON" then
    if prefix ~= VER_PREFIX or not message then return end
    if sender == UnitName("player") then return end
    EnsureDB()
    local v = string.match(message, "^V:([%d%.]+)$")
    if not v then return end
    if VersionNewer(v, PACK_VERSION) then
      NoteVersion(v)
    elseif VersionNewer(PACK_VERSION, v) and not replied[sender] then
      -- l'autre est en retard : on lui repond par la meme voie pour lui dire qu'une version plus recente existe
      replied[sender] = true
      if channel == "WHISPER" then Send("WHISPER", sender) elseif channel then Send(channel) end
    end
  elseif event == "PARTY_MEMBERS_CHANGED" or event == "RAID_ROSTER_UPDATE" then
    -- nouveau groupe / nouveaux membres : on annonce notre version (au plus une fois par 30 s)
    if sent and not groupAt and GetTime() - lastGroup > 30 and GroupChannel() then groupAt = GetTime() + 3 end
  elseif event == "FRIENDLIST_UPDATE" then
    if sent then WhisperFriends() end
  end
end)
ev:SetScript("OnUpdate", function(self)
  if sendAt and not sent and GetTime() >= sendAt then
    sent = true
    Broadcast()
    if ShowFriends then ShowFriends() end     -- rafraichit la liste d'amis (declenche FRIENDLIST_UPDATE)
    WhisperFriends()
  end
  if groupAt and GetTime() >= groupAt then
    groupAt = nil
    lastGroup = GetTime()
    Send(GroupChannel())
  end
end)
