-- MithrilLedger 0.1.0 - WoW 3.3.5 (Interface 30300)
-- Carnet de ventes du vendeur : CR envoyes, paiements recus, commission due/versee.
-- Les sujets des courriers generes par MithrilMail ("Mafia #0037", "Commission #0037")
-- servent de reference. Rien n'est envoye automatiquement.

local TAG = "|cffd4a017MithrilLedger|r "
local MAX_ROWS = 40
local frame, child, rowTexts, totalText
local pending = nil      -- courrier en cours d'envoi
local lastTrade = nil    -- dernier echange d'argent detecte

MithrilLedgerDB = MithrilLedgerDB or {}

local function Print(msg) DEFAULT_CHAT_FRAME:AddMessage(TAG .. tostring(msg)) end

local function Init()
  local d = MithrilLedgerDB
  d.tickets = d.tickets or {}
  d.rate = d.rate or 5
  d.seen = d.seen or {}
  d.debug = d.debug or false
end

local function Dbg(msg)
  if MithrilLedgerDB.debug then Print("|cff999999[debug]|r " .. tostring(msg)) end
end

local function Money(copper)
  copper = copper or 0
  local g = math.floor(copper / 10000)
  local s = math.floor((copper % 10000) / 100)
  local c = copper % 100
  local out = g .. "po"
  if s > 0 then out = out .. " " .. s .. "pa" end
  if c > 0 then out = out .. " " .. c .. "pc" end
  return out
end

local function GetTicket(id, create)
  local t = MithrilLedgerDB.tickets[id]
  if not t and create then
    t = { id = id, buyer = "", sent = 0, paid = 0, comm = 0, created = time() }
    MithrilLedgerDB.tickets[id] = t
  end
  return t
end

local function CommissionDue(t)
  return math.floor((t.paid or 0) * MithrilLedgerDB.rate / 100 + 0.5)
end

-- ---------------------------------------------------------------- interface
local function Refresh()
  if not frame then return end
  local ids = {}
  for id in pairs(MithrilLedgerDB.tickets) do table.insert(ids, id) end
  table.sort(ids, function(a, b) return a > b end)
  local totPaid, totDue, totComm = 0, 0, 0
  for i = 1, MAX_ROWS do
    local fs = rowTexts[i]
    local id = ids[i]
    if id then
      local t = MithrilLedgerDB.tickets[id]
      local due = CommissionDue(t)
      local status
      if (t.paid or 0) <= 0 then
        status = "|cffffcc33en attente de paiement|r"
      elseif (t.comm or 0) >= due then
        status = "|cff44ff44solde|r"
      else
        status = "|cffff5555commission a verser : " .. Money(due - (t.comm or 0)) .. "|r"
      end
      fs:SetText(string.format("#%s %s | CR %s | paye %s | comm. %s/%s | %s",
        id, (t.buyer ~= "" and t.buyer or "?"), Money(t.sent), Money(t.paid), Money(t.comm), Money(due), status))
      fs:Show()
      totPaid = totPaid + (t.paid or 0)
      totDue = totDue + due
      totComm = totComm + (t.comm or 0)
    else
      fs:SetText("")
      fs:Hide()
    end
  end
  child:SetHeight(math.max(1, #ids * 16))
  totalText:SetText(string.format("Encaisse : %s   Commission due : %s   Versee : %s   Reste : %s",
    Money(totPaid), Money(totDue), Money(totComm), Money(math.max(0, totDue - totComm))))
end

local function BuildUI()
  frame = CreateFrame("Frame", "MithrilLedgerFrame", UIParent)
  frame:SetWidth(640)
  frame:SetHeight(420)
  frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  frame:SetFrameStrata("DIALOG")
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
  frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
  })
  frame:Hide()

  local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOP", frame, "TOP", 0, -18)
  title:SetText("Carnet de ventes")

  local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -6, -6)

  local scroll = CreateFrame("ScrollFrame", "MithrilLedgerScroll", frame, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", frame, "TOPLEFT", 20, -48)
  scroll:SetWidth(580)
  scroll:SetHeight(290)
  child = CreateFrame("Frame", nil, scroll)
  child:SetWidth(580)
  child:SetHeight(1)
  scroll:SetScrollChild(child)

  rowTexts = {}
  for i = 1, MAX_ROWS do
    local fs = child:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    fs:SetPoint("TOPLEFT", child, "TOPLEFT", 0, -(i - 1) * 16)
    fs:SetWidth(580)
    fs:SetJustifyH("LEFT")
    rowTexts[i] = fs
  end

  totalText = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  totalText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 22, 52)
  totalText:SetWidth(596)
  totalText:SetJustifyH("LEFT")

  local help = frame:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
  help:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 22, 20)
  help:SetWidth(596)
  help:SetJustifyH("LEFT")
  help:SetText("/mcarnet paye 0037 [po]   /mcarnet comm 0037 [po]   /mcarnet taux 5   /mcarnet solde (retire les tickets soldes)")

  tinsert(UISpecialFrames, "MithrilLedgerFrame")
  frame:SetScript("OnShow", Refresh)
end

local function Toggle()
  if not frame then BuildUI() end
  if frame:IsShown() then frame:Hide() else frame:Show(); Refresh() end
end

-- ------------------------------------------------------- envoi de courriers
local function ApplySent(p)
  local id = string.match(p.subject or "", "Mafia #(%d+)")
  if id and (p.cod or 0) > 0 then
    local t = GetTicket(id, true)
    t.sent = (t.sent or 0) + p.cod
    t.buyer = p.recipient or t.buyer
    Print("CR enregistre : #" .. id .. " pour " .. tostring(p.recipient) .. " (" .. Money(p.cod) .. ")")
  end
  local cid = string.match(p.subject or "", "Commission #(%d+)")
  if cid and (p.money or 0) > 0 then
    local t = GetTicket(cid, true)
    t.comm = (t.comm or 0) + p.money
    Print("Commission versee enregistree : #" .. cid .. " (" .. Money(p.money) .. ")")
  end
  if Refresh then Refresh() end
end

local function OnSendMail(recipient, subject)
  local cod = GetSendMailCOD and GetSendMailCOD() or 0
  local money = GetSendMailMoney and GetSendMailMoney() or 0
  pending = { recipient = recipient, subject = subject, cod = cod, money = money }
  Dbg("SendMail " .. tostring(recipient) .. " / " .. tostring(subject) .. " cod=" .. tostring(cod) .. " money=" .. tostring(money))
end

-- ---------------------------------------------------------- boite de reception
local function ScanInbox()
  if not GetInboxNumItems then return end
  local current = {}
  local n = GetInboxNumItems()
  for i = 1, n do
    local _, _, sender, subject, money = GetInboxHeaderInfo(i)
    if money and money > 0 and sender then
      local key = sender .. "|" .. (subject or "") .. "|" .. money
      local entry = current[key]
      if not entry then
        entry = { count = 0, sender = sender, subject = subject or "", money = money }
        current[key] = entry
      end
      entry.count = entry.count + 1
    end
  end
  local seen = MithrilLedgerDB.seen
  for key, e in pairs(current) do
    local delta = e.count - (seen[key] or 0)
    if delta > 0 then
      local total = delta * e.money
      local id = string.match(e.subject, "Mafia #(%d+)")
      local t = id and GetTicket(id, true) or nil
      if not t then
        -- repli : retrouver le ticket par l'acheteur (si le sujet du paiement est localise)
        for _, cand in pairs(MithrilLedgerDB.tickets) do
          if cand.buyer ~= "" and string.lower(cand.buyer) == string.lower(e.sender)
             and (cand.paid or 0) + total <= (cand.sent or 0) then
            t = cand
            break
          end
        end
      end
      if t then
        t.paid = (t.paid or 0) + total
        if t.buyer == "" then t.buyer = e.sender end
        Print("Paiement recu : #" .. t.id .. " de " .. e.sender .. " (" .. Money(total) .. ")")
      else
        Dbg("courrier d'argent non rattache : " .. e.sender .. " / " .. e.subject .. " / " .. Money(e.money))
      end
    end
    seen[key] = e.count
  end
  for key in pairs(seen) do
    if not current[key] then seen[key] = nil end
  end
  Refresh()
end

-- -------------------------------------------------------------- echanges main a main
local tradeBoth = false
local function OnTradeUpdate()
  local giveMoney = GetPlayerTradeMoney and GetPlayerTradeMoney() or 0
  local getMoney = GetTargetTradeMoney and GetTargetTradeMoney() or 0
  local who = (UnitName and UnitName("NPC")) or "?"
  lastTrade = lastTrade or {}
  lastTrade.give, lastTrade.get, lastTrade.who = giveMoney, getMoney, who
end

local function OnTradeComplete()
  if lastTrade and ((lastTrade.get or 0) > 0 or (lastTrade.give or 0) > 0) then
    if (lastTrade.get or 0) > 0 then
      Print("Echange termine : tu as recu " .. Money(lastTrade.get) .. " de " .. tostring(lastTrade.who) ..
        ". Pour un paiement : /mcarnet paye <ticket>")
    end
    if (lastTrade.give or 0) > 0 then
      Print("Echange termine : tu as donne " .. Money(lastTrade.give) .. " a " .. tostring(lastTrade.who) ..
        ". Pour une commission : /mcarnet comm <ticket>")
    end
    lastTrade.done = true
  end
end

-- ------------------------------------------------------------------ commandes
local function ParseGold(arg)
  local n = tonumber(arg)
  if n and n > 0 then return math.floor(n * 10000) end
  return nil
end

local function Command(msg)
  msg = msg or ""
  local cmd, a1, a2 = strsplit(" ", string.lower(strtrim(msg)))
  if cmd == "" or cmd == nil then
    Toggle()
  elseif cmd == "paye" and a1 then
    local t = GetTicket(a1, true)
    local copper = ParseGold(a2) or (lastTrade and lastTrade.done and lastTrade.get) or nil
    if not copper or copper <= 0 then Print("Indique le montant : /mcarnet paye " .. a1 .. " 250"); return end
    t.paid = (t.paid or 0) + copper
    if lastTrade and lastTrade.done and not ParseGold(a2) then
      t.buyer = (t.buyer == "" and lastTrade.who) or t.buyer
      lastTrade.done = false
    end
    Print("Paiement note : #" .. a1 .. " (" .. Money(copper) .. ")")
    Refresh()
  elseif cmd == "comm" and a1 then
    local t = GetTicket(a1, true)
    local copper = ParseGold(a2)
    if not copper and lastTrade and lastTrade.done and (lastTrade.give or 0) > 0 then
      copper = lastTrade.give
      lastTrade.done = false
    end
    if not copper then copper = math.max(0, CommissionDue(t) - (t.comm or 0)) end
    if copper <= 0 then Print("Rien a verser pour #" .. a1 .. "."); return end
    t.comm = (t.comm or 0) + copper
    Print("Commission versee notee : #" .. a1 .. " (" .. Money(copper) .. ")")
    Refresh()
  elseif cmd == "taux" and tonumber(a1) then
    MithrilLedgerDB.rate = tonumber(a1)
    Print("Taux de commission : " .. a1 .. "%")
    Refresh()
  elseif cmd == "solde" then
    local removed = 0
    for id, t in pairs(MithrilLedgerDB.tickets) do
      if (t.paid or 0) > 0 and (t.comm or 0) >= CommissionDue(t) then
        MithrilLedgerDB.tickets[id] = nil
        removed = removed + 1
      end
    end
    Print(removed .. " ticket(s) solde(s) retire(s).")
    Refresh()
  elseif cmd == "supprimer" and a1 then
    MithrilLedgerDB.tickets[a1] = nil
    Print("Ticket #" .. a1 .. " supprime.")
    Refresh()
  elseif cmd == "debug" then
    MithrilLedgerDB.debug = not MithrilLedgerDB.debug
    Print("Mode debug : " .. tostring(MithrilLedgerDB.debug))
    local names = { "GetInboxNumItems", "GetInboxHeaderInfo", "GetSendMailCOD", "GetSendMailMoney",
      "GetPlayerTradeMoney", "GetTargetTradeMoney", "SendMail" }
    for _, n in ipairs(names) do Print((_G[n] and "OK " or "ABSENT ") .. n) end
  else
    Print("Commandes : /mcarnet | paye <ticket> [po] | comm <ticket> [po] | taux <n> | solde | supprimer <ticket> | debug")
  end
end

SLASH_MITHRILLEDGER1 = "/mcarnet"
SlashCmdList["MITHRILLEDGER"] = Command

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("MAIL_SHOW")
ev:RegisterEvent("MAIL_INBOX_UPDATE")
ev:RegisterEvent("MAIL_SEND_SUCCESS")
ev:RegisterEvent("MAIL_FAILED")
ev:RegisterEvent("TRADE_MONEY_CHANGED")
ev:RegisterEvent("TRADE_ACCEPT_UPDATE")
ev:RegisterEvent("UI_INFO_MESSAGE")
ev:SetScript("OnEvent", function(self, event, arg1)
  if event == "PLAYER_LOGIN" then
    Init()
    if hooksecurefunc and SendMail then hooksecurefunc("SendMail", OnSendMail) end
    Print("charge. /mcarnet pour ouvrir le carnet.")
  elseif not MithrilLedgerDB.tickets then
    return
  elseif event == "MAIL_SHOW" or event == "MAIL_INBOX_UPDATE" then
    ScanInbox()
  elseif event == "MAIL_SEND_SUCCESS" then
    if pending then ApplySent(pending); pending = nil end
  elseif event == "MAIL_FAILED" then
    pending = nil
  elseif event == "TRADE_MONEY_CHANGED" or event == "TRADE_ACCEPT_UPDATE" then
    OnTradeUpdate()
  elseif event == "UI_INFO_MESSAGE" then
    if ERR_TRADE_COMPLETE and arg1 == ERR_TRADE_COMPLETE then OnTradeComplete() end
  end
end)

_G.MithrilLedger = { Command = Command, ApplySent = ApplySent, ScanInbox = ScanInbox, CommissionDue = CommissionDue, Money = Money }
