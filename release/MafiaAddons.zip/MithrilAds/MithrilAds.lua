-- MithrilAds 0.1.0 - WoW 3.3.5 (Interface 30300)
-- Prepare une annonce (max 255 caracteres), l'envoie dans le canal choisi quand TU
-- cliques sur "Envoyer", et te rappelle quand elle peut etre republiee.
-- Aucun envoi automatique. Shift-clic sur un objet dans le champ pour inserer son lien.

local TAG = "|cffd4a017MithrilAds|r "
local MAX_LEN = 255
local DEFAULT_DISCORD = "https://discord.gg/ZVgDxnp4ms"
local frame, edit, counter, channelEdit, intervalEdit, discordEdit, timerText
local nextAt = nil
local reminded = true

MithrilAdsDB = MithrilAdsDB or {}

local function Print(msg) DEFAULT_CHAT_FRAME:AddMessage(TAG .. tostring(msg)) end

local function Init()
  local d = MithrilAdsDB
  d.slots = d.slots or { "", "", "" }
  d.discord = d.discord or DEFAULT_DISCORD
  d.channel = d.channel or 2
  d.interval = d.interval or 5
  d.slot = d.slot or 1
end

-- Remplace {discord} par le lien configure
local function Expand(text)
  local out = string.gsub(text or "", "{discord}", MithrilAdsDB.discord or DEFAULT_DISCORD)
  return out
end

local function Length(text) return string.len(Expand(text)) end

local function UpdateCounter()
  if not counter then return end
  local n = Length(edit:GetText())
  local color = (n > MAX_LEN) and "|cffff5555" or "|cff44ff44"
  counter:SetText(color .. n .. " / " .. MAX_LEN .. "|r")
end

local function SaveSlot()
  MithrilAdsDB.slots[MithrilAdsDB.slot] = edit:GetText()
end

local function LoadSlot(i)
  MithrilAdsDB.slot = i
  edit:SetText(MithrilAdsDB.slots[i] or "")
  UpdateCounter()
end

local function Send()
  local text = Expand(edit:GetText())
  if text == "" then Print("Le message est vide."); return end
  if string.len(text) > MAX_LEN then
    Print("Message trop long (" .. string.len(text) .. " / " .. MAX_LEN .. "). Raccourcis-le.")
    return
  end
  local ch = tonumber(channelEdit:GetText()) or MithrilAdsDB.channel
  MithrilAdsDB.channel = ch
  SaveSlot()
  SendChatMessage(text, "CHANNEL", nil, ch)
  local minutes = tonumber(intervalEdit:GetText()) or MithrilAdsDB.interval
  MithrilAdsDB.interval = minutes
  nextAt = GetTime() + minutes * 60
  reminded = false
  Print("Annonce envoyee dans le canal " .. ch .. ". Rappel dans " .. minutes .. " min.")
end

local function BuildUI()
  frame = CreateFrame("Frame", "MithrilAdsFrame", UIParent)
  frame:SetWidth(520)
  frame:SetHeight(380)
  frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  frame:SetFrameStrata("DIALOG")
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
  frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
  })
  frame:Hide()

  local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOP", frame, "TOP", 0, -18)
  title:SetText("Annonces de vente")
  local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -6, -6)

  -- 3 emplacements de message
  for i = 1, 3 do
    local b = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    b:SetWidth(70); b:SetHeight(22)
    b:SetPoint("TOPLEFT", frame, "TOPLEFT", 22 + (i - 1) * 76, -44)
    b:SetText("Msg " .. i)
    b:SetScript("OnClick", function() SaveSlot(); LoadSlot(i) end)
  end

  local scroll = CreateFrame("ScrollFrame", "MithrilAdsScroll", frame, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -74)
  scroll:SetWidth(450)
  scroll:SetHeight(110)
  edit = CreateFrame("EditBox", "MithrilAdsEdit", scroll)
  edit:SetMultiLine(true)
  edit:SetAutoFocus(false)
  edit:SetFontObject(ChatFontNormal)
  edit:SetWidth(440)
  edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  edit:SetScript("OnTextChanged", UpdateCounter)
  scroll:SetScrollChild(edit)

  counter = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  counter:SetPoint("TOPLEFT", frame, "TOPLEFT", 24, -192)

  local function Label(text, x, y)
    local fs = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    fs:SetPoint("TOPLEFT", frame, "TOPLEFT", x, y)
    fs:SetText(text)
    return fs
  end
  local function Box(name, x, y, w, val)
    local e = CreateFrame("EditBox", name, frame, "InputBoxTemplate")
    e:SetWidth(w); e:SetHeight(20)
    e:SetPoint("TOPLEFT", frame, "TOPLEFT", x, y)
    e:SetAutoFocus(false)
    e:SetText(tostring(val))
    return e
  end

  Label("Canal (numero)", 24, -222)
  channelEdit = Box("MithrilAdsChannel", 30, -238, 40, MithrilAdsDB.channel)
  Label("Rappel (min)", 130, -222)
  intervalEdit = Box("MithrilAdsInterval", 136, -238, 40, MithrilAdsDB.interval)
  Label("Lien Discord ({discord})", 230, -222)
  discordEdit = Box("MithrilAdsDiscord", 236, -238, 240, MithrilAdsDB.discord)
  discordEdit:SetScript("OnTextChanged", function(self)
    MithrilAdsDB.discord = self:GetText()
    UpdateCounter()
  end)

  local send = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  send:SetWidth(120); send:SetHeight(26)
  send:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -274)
  send:SetText("Envoyer")
  send:SetScript("OnClick", Send)

  timerText = frame:CreateFontString(nil, "ARTWORK", "GameFontNormal")
  timerText:SetPoint("LEFT", send, "RIGHT", 14, 0)

  local help = frame:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
  help:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 22, 20)
  help:SetWidth(470)
  help:SetJustifyH("LEFT")
  help:SetText("Shift-clic sur un objet pour inserer son lien. {discord} est remplace par le lien. L'envoi est toujours manuel.")

  tinsert(UISpecialFrames, "MithrilAdsFrame")
  frame:SetScript("OnUpdate", function()
    if nextAt then
      local left = nextAt - GetTime()
      if left > 0 then
        timerText:SetText(string.format("Prochain envoi possible dans %d:%02d", math.floor(left / 60), math.floor(left % 60)))
      else
        timerText:SetText("|cff44ff44Tu peux republier.|r")
      end
    end
  end)
  LoadSlot(MithrilAdsDB.slot)
end

local function Toggle()
  if not frame then BuildUI() end
  if frame:IsShown() then frame:Hide() else frame:Show() end
end

-- Rappel meme quand la fenetre est fermee
local watcher = CreateFrame("Frame")
watcher:SetScript("OnUpdate", function()
  if nextAt and not reminded and GetTime() >= nextAt then
    reminded = true
    Print("Tu peux republier ton annonce : /mannonce")
    if UIErrorsFrame then UIErrorsFrame:AddMessage("MithrilAds : tu peux republier ton annonce", 1, 0.8, 0.1) end
  end
end)

SLASH_MITHRILADS1 = "/mannonce"
SlashCmdList["MITHRILADS"] = function() Toggle() end

local ev = CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function()
  Init()
  Print("charge. /mannonce pour preparer une annonce.")
end)

_G.MithrilAds = { Expand = Expand, Length = Length }
