-- MithrilMail 0.1.0 - WoW 3.3.5 (Interface 30300)
-- Colle les lignes fournies par le bot, puis "Preparer" pre-remplit le courrier.
-- Le joueur verifie, joint l'objet et clique lui-meme sur Envoyer.
-- Format : MITHRIL1|MODE|destinataire|sujet|cuivre   (MODE = COD ou MONEY)

local ADDON = "MithrilMail"
local TAG = "MITHRIL1"
local MAX_ROWS = 8
local MAX_COPPER = 2147483647

MithrilMailDB = MithrilMailDB or {}
local entries = {}
local rows = {}
local frame, editBox, statusText
local debugMode = false

local function Print(msg)
  DEFAULT_CHAT_FRAME:AddMessage("|cff66ccffMithrilMail|r " .. tostring(msg))
end

local function Dbg(msg)
  if debugMode then Print("|cff999999[debug]|r " .. tostring(msg)) end
end

local function Trim(s)
  return (string.gsub(s or "", "^%s*(.-)%s*$", "%1"))
end

local function FormatMoney(copper)
  local g = math.floor(copper / 10000)
  local sv = math.floor((copper % 10000) / 100)
  local c = copper % 100
  local out = g .. "po"
  if sv > 0 then out = out .. " " .. sv .. "pa" end
  if c > 0 then out = out .. " " .. c .. "pc" end
  return out
end

-- Renvoie une entree {mode, to, subject, copper} ou nil, raison
local function ParseLine(line)
  line = Trim(line)
  if line == "" then return nil, "vide" end
  local tag, mode, to, subject, amount = strsplit("|", line)
  if tag ~= TAG then return nil, "format inconnu" end
  mode = string.upper(Trim(mode))
  if mode ~= "COD" and mode ~= "MONEY" then return nil, "mode invalide" end
  to = Trim(to)
  subject = Trim(subject)
  local copper = tonumber(Trim(amount))
  if to == "" then return nil, "destinataire vide" end
  if not copper or copper <= 0 or copper > MAX_COPPER or copper ~= math.floor(copper) then
    return nil, "montant invalide"
  end
  return { mode = mode, to = to, subject = subject, copper = copper }
end

local function ParseText(text)
  local list, errors = {}, {}
  for line in string.gmatch((text or "") .. "\n", "([^\r\n]*)[\r\n]") do
    if Trim(line) ~= "" then
      local entry, reason = ParseLine(line)
      if entry then
        table.insert(list, entry)
      else
        table.insert(errors, reason .. " : " .. string.sub(line, 1, 40))
      end
    end
  end
  return list, errors
end

local function SetStatus(msg, r, g, b)
  if statusText then
    statusText:SetText(msg or "")
    statusText:SetTextColor(r or 1, g or 1, b or 1)
  end
end

-- Execute une etape protegee ; en cas d'erreur, la signale sans casser le reste.
local function Step(label, fn)
  local ok, err = pcall(fn)
  if ok then
    Dbg("OK  " .. label)
  else
    Print("|cffff4444Etape en echec : " .. label .. "|r " .. tostring(err))
  end
  return ok
end

local function PrepareMail(entry)
  if not (MailFrame and MailFrame:IsShown()) then
    SetStatus("Ouvre d'abord la boite aux lettres (clique sur une boite).", 1, 0.3, 0.3)
    Print("Ouvre d'abord la boite aux lettres, puis reclique sur Preparer.")
    return false
  end
  Step("onglet Envoyer", function()
    if MailFrameTab2 then MailFrameTab2:Click() end
  end)
  Step("destinataire", function()
    SendMailNameEditBox:SetText(entry.to)
  end)
  Step("sujet", function()
    SendMailSubjectEditBox:SetText(entry.subject or "")
  end)
  Step("mode " .. entry.mode, function()
    if entry.mode == "COD" then
      if SendMailRadioButton_OnClick then
        SendMailRadioButton_OnClick(2)
      end
      if SendMailCODButton then SendMailCODButton:SetChecked(1) end
      if SendMailSendMoneyButton then SendMailSendMoneyButton:SetChecked(nil) end
    else
      if SendMailRadioButton_OnClick then
        SendMailRadioButton_OnClick(1)
      end
      if SendMailSendMoneyButton then SendMailSendMoneyButton:SetChecked(1) end
      if SendMailCODButton then SendMailCODButton:SetChecked(nil) end
    end
  end)
  Step("montant", function()
    MoneyInputFrame_SetCopper(SendMailMoney, entry.copper)
  end)
  Step("mise a jour", function()
    if SendMailFrame_Update then SendMailFrame_Update() end
  end)
  local label = (entry.mode == "COD" and "CR " or "Argent ") .. FormatMoney(entry.copper)
  SetStatus("Pret : " .. entry.to .. " - " .. label .. ". Joins l'objet (CR) puis Envoyer.", 0.4, 1, 0.4)
  return true
end

local function RefreshRows()
  for i = 1, MAX_ROWS do
    local row = rows[i]
    local e = entries[i]
    if e then
      local kind = (e.mode == "COD") and "CR" or "Argent"
      row.text:SetText(i .. ". " .. e.to .. " - " .. kind .. " " .. FormatMoney(e.copper) .. "  (" .. e.subject .. ")")
      row.button:SetScript("OnClick", function() PrepareMail(e) end)
      row:Show()
    else
      row:Hide()
    end
  end
end

local function LoadFromBox()
  local list, errors = ParseText(editBox:GetText())
  entries = {}
  for i = 1, math.min(#list, MAX_ROWS) do entries[i] = list[i] end
  RefreshRows()
  if #list > MAX_ROWS then
    SetStatus(#list .. " lignes, seules les " .. MAX_ROWS .. " premieres sont affichees.", 1, 0.8, 0.2)
  elseif #errors > 0 then
    SetStatus(#errors .. " ligne(s) ignoree(s) : " .. errors[1], 1, 0.6, 0.2)
  elseif #list == 0 then
    SetStatus("Aucune ligne valide.", 1, 0.3, 0.3)
  else
    SetStatus(#list .. " courrier(s) pret(s).", 0.4, 1, 0.4)
  end
end

local function BuildUI()
  frame = CreateFrame("Frame", "MithrilMailFrame", UIParent)
  frame:SetWidth(520)
  frame:SetHeight(420)
  frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
  frame:SetFrameStrata("DIALOG")
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
  frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
  frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile = true, tileSize = 32, edgeSize = 32,
    insets = { left = 11, right = 12, top = 12, bottom = 11 },
  })
  frame:Hide()

  local title = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
  title:SetPoint("TOP", frame, "TOP", 0, -18)
  title:SetText("MithrilMail")

  local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -6, -6)

  local help = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
  help:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -42)
  help:SetWidth(476)
  help:SetJustifyH("LEFT")
  help:SetText("Colle les lignes du bot (bouton Courriers), clique Charger, ouvre la boite aux lettres puis Preparer.")

  local scroll = CreateFrame("ScrollFrame", "MithrilMailScroll", frame, "UIPanelScrollFrameTemplate")
  scroll:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -68)
  scroll:SetWidth(450)
  scroll:SetHeight(100)

  editBox = CreateFrame("EditBox", "MithrilMailEditBox", scroll)
  editBox:SetMultiLine(true)
  editBox:SetAutoFocus(false)
  editBox:SetFontObject(ChatFontNormal)
  editBox:SetWidth(440)
  editBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  scroll:SetScrollChild(editBox)

  local load = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  load:SetWidth(100)
  load:SetHeight(24)
  load:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -176)
  load:SetText("Charger")
  load:SetScript("OnClick", LoadFromBox)

  local clear = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
  clear:SetWidth(100)
  clear:SetHeight(24)
  clear:SetPoint("LEFT", load, "RIGHT", 8, 0)
  clear:SetText("Vider")
  clear:SetScript("OnClick", function()
    editBox:SetText("")
    entries = {}
    RefreshRows()
    SetStatus("")
  end)

  for i = 1, MAX_ROWS do
    local row = CreateFrame("Frame", nil, frame)
    row:SetWidth(476)
    row:SetHeight(24)
    row:SetPoint("TOPLEFT", frame, "TOPLEFT", 22, -208 - (i - 1) * 26)
    row.button = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.button:SetWidth(80)
    row.button:SetHeight(22)
    row.button:SetPoint("LEFT", row, "LEFT", 0, 0)
    row.button:SetText("Preparer")
    row.text = row:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    row.text:SetPoint("LEFT", row.button, "RIGHT", 8, 0)
    row.text:SetWidth(380)
    row.text:SetJustifyH("LEFT")
    row:Hide()
    rows[i] = row
  end

  statusText = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
  statusText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 22, 18)
  statusText:SetWidth(476)
  statusText:SetJustifyH("LEFT")

  tinsert(UISpecialFrames, "MithrilMailFrame")
end

local function Toggle()
  if not frame then BuildUI() end
  if frame:IsShown() then frame:Hide() else frame:Show() end
end

local function DebugReport()
  Print("Interface " .. tostring(select(4, GetBuildInfo())) .. " - verification des elements du courrier :")
  local names = {
    "MailFrame", "MailFrameTab2", "SendMailFrame", "SendMailNameEditBox",
    "SendMailSubjectEditBox", "SendMailMoney", "SendMailCODButton",
    "SendMailSendMoneyButton", "MoneyInputFrame_SetCopper",
    "SendMailRadioButton_OnClick", "SendMailFrame_Update",
  }
  for _, n in ipairs(names) do
    Print((_G[n] and "|cff44ff44OK|r " or "|cffff4444ABSENT|r ") .. n)
  end
  Print("Mode debug actif : chaque etape de Preparer est detaillee.")
end

SLASH_MITHRILMAIL1 = "/mithril"
SlashCmdList["MITHRILMAIL"] = function(msg)
  msg = string.lower(Trim(msg))
  if msg == "debug" then
    debugMode = true
    DebugReport()
  elseif msg == "test" then
    if not frame then BuildUI() end
    editBox:SetText(
      "MITHRIL1|COD|Testperso|Mafia #0001|400000\n" ..
      "MITHRIL1|MONEY|Testperso|Commission #0001|20000"
    )
    frame:Show()
    LoadFromBox()
  else
    Toggle()
  end
end

-- Point d'entree pour les tests hors du jeu
_G.MithrilMail = {
  ParseLine = ParseLine,
  ParseText = ParseText,
  FormatMoney = FormatMoney,
  PrepareMail = PrepareMail,
}

local loader = CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:SetScript("OnEvent", function()
  Print("charge. Tape /mithril pour ouvrir la fenetre (/mithril debug en cas de souci).")

end)
